$ErrorActionPreference = 'Stop'
$evidence = 'F:\JericoEngine\JericoEngine\build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-profile-install-attempt5'
$repo = 'F:\JericoEngine\JericoEngine'
$freezePath = Join-Path $evidence 'frozen-install-inputs.json'
$freeze = Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
$preflight = Get-Content -LiteralPath (Join-Path $evidence 'preflight-reconciled.json') -Raw | ConvertFrom-Json
if (!$preflight.gate) { throw 'Reconciled preflight gate was not true.' }
if (Test-Path -LiteralPath $freeze.prefix) { throw 'Install prefix is no longer absent.' }
if (![string]::IsNullOrEmpty([Environment]::GetEnvironmentVariable('DESTDIR'))) { throw 'DESTDIR is not empty.' }
$psi = [Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $freeze.executable
$psi.WorkingDirectory = $repo
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.Environment['MSBUILDDISABLENODEREUSE'] = '1'
foreach ($arg in $freeze.argv) { [void]$psi.ArgumentList.Add([string]$arg) }
$startedUtc = [DateTime]::UtcNow.ToString('o')
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
$process = [Diagnostics.Process]::new()
$process.StartInfo = $psi
if (!$process.Start()) { throw 'CMake install process did not start.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$startRecord = [pscustomobject]@{startedUtc=$startedUtc;pid=$process.Id;executable=$psi.FileName;argv=@($freeze.argv);workingDirectory=$psi.WorkingDirectory;creationUtc=$process.StartTime.ToUniversalTime().ToString('o');freezeSHA256=(Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash;prefix=$freeze.prefix;prefixWasAbsent=$true;destdirWasEmpty=$true;nodeReuseEnv=$psi.Environment['MSBUILDDISABLENODEREUSE']}
$startRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'install-start.json') -Encoding utf8
$process.WaitForExit()
$nativeExit = $process.ExitCode
[IO.File]::WriteAllText((Join-Path $evidence 'native-exit.txt'), [string]$nativeExit)
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText((Join-Path $evidence 'stdout.log'), $stdout)
[IO.File]::WriteAllText((Join-Path $evidence 'stderr.log'), $stderr)
$stopwatch.Stop()
$result = [pscustomobject]@{startedUtc=$startedUtc;completedUtc=[DateTime]::UtcNow.ToString('o');pid=$process.Id;nativeExit=$nativeExit;elapsedSeconds=[math]::Round($stopwatch.Elapsed.TotalSeconds,3);stdoutBytes=[Text.Encoding]::UTF8.GetByteCount($stdout);stderrBytes=[Text.Encoding]::UTF8.GetByteCount($stderr);stdoutSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'stdout.log') -Algorithm SHA256).Hash;stderrSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'stderr.log') -Algorithm SHA256).Hash}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'install-result.json') -Encoding utf8
Write-Output ("INSTALL_NATIVE_EXIT=" + $nativeExit)
Write-Output ("INSTALL_PID=" + $process.Id)
Write-Output ("ELAPSED_SECONDS=" + $result.elapsedSeconds)
