$ErrorActionPreference = 'Stop'
$repo = 'F:\JericoEngine\JericoEngine'
$engine = Join-Path $repo 'build\n0-validation\original-engine'
$attempt = Join-Path $repo 'build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-profile-install-attempt2'
$prefix = Join-Path $attempt 'prefix'
$freezePath = Join-Path $attempt 'frozen-install-inputs.json'
$freeze = Get-Content -Raw $freezePath | ConvertFrom-Json
$sourceFreezePath = $freeze.sourceBuildFreeze
$sourceFreeze = Get-Content -Raw $sourceFreezePath | ConvertFrom-Json
$rootInstall = Join-Path $engine 'cmake_install.cmake'
$cachePath = Join-Path $engine 'CMakeCache.txt'
$cmakeExe = $freeze.executable
$auditPath = $freeze.auditReview
$buildResultPath = Join-Path $repo 'build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-missing-profile-payloads-build-attempt2\build-result.json'

function Get-HashRecord($entry) {
    if (-not (Test-Path -LiteralPath $entry.path -PathType Leaf)) { return [pscustomobject]@{path=$entry.path; exists=$false; bytes=$null; sha256=$null; expectedBytes=$entry.bytes; expectedSha256=$entry.sha256} }
    $item = Get-Item -LiteralPath $entry.path -Force
    $hash = (Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash
    return [pscustomobject]@{path=$entry.path; exists=$true; bytes=[long]$item.Length; sha256=$hash; expectedBytes=$entry.bytes; expectedSha256=$entry.sha256; match=([long]$item.Length -eq [long]$entry.bytes -and $hash -eq $entry.sha256)}
}

$inputResults = @($freeze.inputs | ForEach-Object { Get-HashRecord $_ })
$sourceResults = @($sourceFreeze.SourceInputs | ForEach-Object { Get-HashRecord $_ })
$projectResults = @($sourceFreeze.ProjectInputs | ForEach-Object { Get-HashRecord $_ })
$payloadResults = @((Get-Content -Raw $buildResultPath | ConvertFrom-Json).outputFiles | ForEach-Object {
    $path = $_.path
    $exists = Test-Path -LiteralPath $path -PathType Leaf
    if ($exists) { $it = Get-Item -LiteralPath $path; $h = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash; [pscustomobject]@{path=$path;exists=$true;bytes=[long]$it.Length;sha256=$h;expectedBytes=$_.bytes;expectedSha256=$_.sha256;match=([long]$it.Length -eq [long]$_.bytes -and $h -eq $_.sha256)} } else { [pscustomobject]@{path=$path;exists=$false;bytes=$null;sha256=$null;expectedBytes=$_.bytes;expectedSha256=$_.sha256;match=$false} }
})
$fixedInputs = @(
    [pscustomobject]@{path=$cachePath;sha256=(Get-FileHash -LiteralPath $cachePath -Algorithm SHA256).Hash;expected=$freeze.cacheSHA256},
    [pscustomobject]@{path=$rootInstall;sha256=(Get-FileHash -LiteralPath $rootInstall -Algorithm SHA256).Hash},
    [pscustomobject]@{path=$cmakeExe;sha256=(Get-FileHash -LiteralPath $cmakeExe -Algorithm SHA256).Hash;expected=$freeze.executableSHA256},
    [pscustomobject]@{path=$auditPath;sha256=(Get-FileHash -LiteralPath $auditPath -Algorithm SHA256).Hash;expected=$freeze.auditReviewSHA256}
)

$manifestPath = Join-Path $engine 'install_manifest.txt'
$manifestBackup = Join-Path $attempt 'install_manifest.txt'
Copy-Item -LiteralPath $manifestPath -Destination $manifestBackup -Force
$manifestLines = @(Get-Content -LiteralPath $manifestPath | Where-Object { $_ -ne '' })
$prefixFull = [IO.Path]::GetFullPath($prefix).TrimEnd('\') + '\'
$manifestRecords = [System.Collections.Generic.List[object]]::new()
$manifestEscapes = [System.Collections.Generic.List[string]]::new()
$manifestMissing = [System.Collections.Generic.List[string]]::new()
$manifestSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($line in $manifestLines) {
    $normalized = [IO.Path]::GetFullPath($line)
    if (-not $normalized.StartsWith($prefixFull, [StringComparison]::OrdinalIgnoreCase)) { $manifestEscapes.Add($line); continue }
    [void]$manifestSet.Add($normalized)
    if (-not (Test-Path -LiteralPath $normalized -PathType Leaf)) { $manifestMissing.Add($normalized); continue }
    $it = Get-Item -LiteralPath $normalized -Force
    $manifestRecords.Add([pscustomobject]@{path=$normalized;relativePath=$normalized.Substring($prefixFull.Length);bytes=[long]$it.Length;sha256=(Get-FileHash -LiteralPath $normalized -Algorithm SHA256).Hash})
}

$allFiles = @(Get-ChildItem -LiteralPath $prefix -File -Recurse -Force)
$installedRecords = [System.Collections.Generic.List[object]]::new()
$lfsPointers = [System.Collections.Generic.List[object]]::new()
$reparse = [System.Collections.Generic.List[string]]::new()
foreach ($it in $allFiles) {
    if (($it.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { $reparse.Add($it.FullName) }
    $h = (Get-FileHash -LiteralPath $it.FullName -Algorithm SHA256).Hash
    $rel = $it.FullName.Substring($prefixFull.Length)
    $installedRecords.Add([pscustomobject]@{relativePath=$rel;bytes=[long]$it.Length;sha256=$h})
    if ($it.Length -ge 40) {
        $stream = [IO.File]::OpenRead($it.FullName)
        try { $buf = New-Object byte[] 64; $n = $stream.Read($buf,0,64); $head = [Text.Encoding]::ASCII.GetString($buf,0,$n) } finally { $stream.Dispose() }
        if ($head.StartsWith('version https://git-lfs.github.com/spec/v1')) { $lfsPointers.Add([pscustomobject]@{relativePath=$rel;bytes=[long]$it.Length;sha256=$h}) }
    }
}
$extras = @($installedRecords | Where-Object { -not $manifestSet.Contains([IO.Path]::GetFullPath((Join-Path $prefix $_.relativePath))) } | ForEach-Object { $_.relativePath })
$forbiddenExeNames = @('MaterialEditor.exe','MaterialCanvas.exe','PassCanvas.exe','O3DEQtControlGallery.exe','ReflectedPropertyEditorStandalone.exe','DPEDebugViewStandalone.exe')
$rootBin = Join-Path $prefix 'bin\Windows\profile\Default'
$forbidden = @($forbiddenExeNames | ForEach-Object { Join-Path $rootBin $_ } | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
$requiredRel = @('bin\Windows\profile\Default\ShaderManagementConsole.exe','bin\Windows\profile\Default\Atom_Bootstrap.dll','bin\Windows\profile\Default\ProfilerCapture.dll','bin\Windows\profile\Default\RenderDebug.dll')
$required = @($requiredRel | ForEach-Object { $full=Join-Path $prefix $_; [pscustomobject]@{relativePath=$_;exists=(Test-Path -LiteralPath $full -PathType Leaf);bytes=if(Test-Path -LiteralPath $full -PathType Leaf){(Get-Item -LiteralPath $full).Length}else{$null};sha256=if(Test-Path -LiteralPath $full -PathType Leaf){(Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash}else{$null}} })

$inputMismatch = @($inputResults | Where-Object { -not $_.match })
$sourceMismatch = @($sourceResults | Where-Object { -not $_.match })
$projectMismatch = @($projectResults | Where-Object { -not $_.match })
$payloadMismatch = @($payloadResults | Where-Object { -not $_.match })
$postflight = [ordered]@{
    utc=(Get-Date).ToUniversalTime().ToString('o'); frozenInputCount=$freeze.inputCount; frozenInputsMatched=$inputResults.Count-$inputMismatch.Count; frozenInputMismatches=$inputMismatch
    sourceInputCount=$sourceFreeze.SourceInputCount; sourceInputsMatched=$sourceResults.Count-$sourceMismatch.Count; sourceInputMismatches=$sourceMismatch
    projectInputCount=$sourceFreeze.ProjectCount; projectInputsMatched=$projectResults.Count-$projectMismatch.Count; projectInputMismatches=$projectMismatch
    payloadCount=$payloadResults.Count; payloadsMatched=@($payloadResults | Where-Object match).Count; payloadMismatches=$payloadMismatch
    fixedHashes=$fixedInputs; manifestPath=$manifestPath; manifestBackup=$manifestBackup; manifestSha256=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash; manifestCount=$manifestLines.Count
}
$postflight | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $attempt 'postflight.json') -Encoding utf8
$installedRecords | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $attempt 'installed-files.json') -Encoding utf8
$manifestRecords | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $attempt 'manifest-files.json') -Encoding utf8
$verification = [ordered]@{
    status=if($manifestEscapes.Count -eq 0 -and $manifestMissing.Count -eq 0 -and $reparse.Count -eq 0 -and $forbidden.Count -eq 0 -and @($required | Where-Object { -not $_.exists }).Count -eq 0){'INSTALL_LAYOUT_VERIFIED'}else{'INSTALL_LAYOUT_HAS_FINDINGS'}
    prefix=$prefix; installedFileCount=$allFiles.Count; installedBytes=($allFiles | Measure-Object -Property Length -Sum).Sum; manifestCount=$manifestLines.Count; manifestInPrefixCount=$manifestRecords.Count
    manifestEscapes=$manifestEscapes; manifestMissing=$manifestMissing; reparseEntries=$reparse; unlistedInstalledFiles=$extras; lfsPointerCount=$lfsPointers.Count; lfsPointers=$lfsPointers
    forbiddenExecutableNames=$forbiddenExeNames; forbiddenExecutablesFound=$forbidden; requiredPayloads=$required
}
$verification | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $attempt 'install-verification.json') -Encoding utf8