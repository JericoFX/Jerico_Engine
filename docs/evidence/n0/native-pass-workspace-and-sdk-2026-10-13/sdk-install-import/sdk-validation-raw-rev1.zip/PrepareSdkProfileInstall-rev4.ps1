$ErrorActionPreference = 'Stop'
$ar = $PSScriptRoot
$repo = 'F:\JericoEngine\JericoEngine'
$build = Join-Path $repo 'build\n0-validation\original-engine'
$phase = Join-Path $ar 'sdk-profile-configure-attempt6'
$installPhase = Join-Path $ar 'sdk-profile-install-attempt4'
$prefix = Join-Path $installPhase 'prefix'
function ReadJson([string]$path) { Get-Content -LiteralPath $path -Raw | ConvertFrom-Json }
function Pin([string]$path) {
    $item = Get-Item -LiteralPath $path
    [pscustomobject]@{path=$item.FullName;bytes=$item.Length;sha256=(Get-FileHash -LiteralPath $path).Hash}
}
function WriteNew([string]$path, $value) {
    $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew)
    try { $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 12)); $stream.Write($bytes,0,$bytes.Length) } finally { $stream.Dispose() }
}
$configured = ReadJson (Join-Path $phase 'configure-result.json')
$configurePostflight = ReadJson (Join-Path $phase 'postflight.json')
if($configured.exit -ne 0 -or [int](Get-Content -LiteralPath (Join-Path $phase 'native-exit.txt') -Raw) -ne 0 -or @($configurePostflight.inputMismatches).Count -or @($configurePostflight.cacheMismatches).Count -or @($configurePostflight.otherEngineJsonDifferences).Count) { throw 'Configure did not pass frozen-input checks' }
$rootPin = Pin (Join-Path $build 'cmake_install.cmake')
& (Join-Path $ar 'CheckGeneratedSdk.ps1') -BuildRoot $build -RootInstallSHA256 $rootPin.sha256 -ResultPath (Join-Path $phase 'generated-config-check.json')

# Compare real generated compiler/linker/library options, not just cached flags.
$baseline = ReadJson (Join-Path $ar 'sdk-profile-configure-attempt1\productive-compile-options.before.json')
$optionDifferences = @()
foreach($entry in $baseline) {
    [xml]$xml=[IO.File]::ReadAllText($entry.path)
    $nodes=$xml.SelectNodes("/*[local-name()='Project']/*[local-name()='ItemDefinitionGroup']/*[local-name()='ClCompile' or local-name()='Link' or local-name()='Lib']")
    $text=($nodes | ForEach-Object { $_.OuterXml }) -join "`n"
    $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.UTF8Encoding]::new($false).GetBytes($text)))
    if($nodes.Count -ne $entry.nodeCount -or $hash -cne $entry.optionsSHA256) { $optionDifferences += [pscustomobject]@{path=$entry.path;before=$entry.optionsSHA256;after=$hash;nodes=$nodes.Count} }
}
WriteNew (Join-Path $phase 'productive-options-parity.json') ([ordered]@{utc=[DateTime]::UtcNow.ToString('o');status='PRODUCTIVE_OPTIONS_COMPARED_AFTER_REAL_CONFIGURE';nativeConfigureExit=0;projectCount=$baseline.Count;matched=($baseline.Count-$optionDifferences.Count);differences=$optionDifferences;algorithm='ClCompile/Link/Lib children under XML ItemDefinitionGroup; OuterXml joined LF, SHA256 UTF8 without BOM';limit='Physical projects include compiler IDs and obsolete targets; active generated exports/loader checked separately.'})
if($optionDifferences.Count) { throw 'Productive compiler/linker options changed' }

# The source build stays valid: only SDK metadata changed after its successful run.
$sourceFreeze = ReadJson (Join-Path $ar 'sdk-profile-configure-attempt5\source-build-inputs-after-sdk-config.json')
$sourceChanged = @()
foreach($entry in $sourceFreeze.SourceInputs) {
    $actual=Pin $entry.path
    if($actual.sha256 -cne $entry.sha256 -or $actual.bytes -ne $entry.bytes) {
        if($actual.path -ine (Join-Path $repo 'cmake\Platform\Common\Install_common.cmake') -or $entry.sha256 -cne '3830B3D226EEC3F9D133F5C2FE63958136C14D211E1A0BE31E213930F1553B21' -or $actual.sha256 -cne '68127B0ED707885E71F3B7ED6C22AA359E9A065A81735CB50E63B8F1B3573EC3') { throw "Unexpected source build input change: $($entry.path)" }
        $sourceChanged += [pscustomobject]@{path=$actual.path;before=$entry.sha256;after=$actual.sha256}
        $entry.bytes=$actual.bytes; $entry.sha256=$actual.sha256
    }
}
foreach($entry in $sourceFreeze.ProjectInputs) { $actual=Pin $entry.path; if($actual.sha256 -cne $entry.sha256) { throw "Generated project drift: $($entry.path)" } }
$buildResult=ReadJson (Join-Path $ar 'sdk-missing-profile-payloads-build-attempt2\build-result.json')
if($buildResult.exitCode -ne 0) { throw 'Build did not pass' }
foreach($entry in $buildResult.outputFiles) { $actual=Pin $entry.path; if($actual.sha256 -cne $entry.sha256 -or $actual.bytes -ne $entry.bytes) { throw "Built payload drift: $($entry.path)" } }
$sourceFreeze.Status='SOURCE_BUILD_REUSED_UNCHANGED_CODE_OPTIONS_OUTPUTS_WITH_REVIEWED_SDK_METADATA_DELTA'
$sourceFreeze.Utc=[DateTime]::UtcNow.ToString('o')
$sourceFreeze.Owner='root'
$sourceFreeze.RootInstallSHA256=$rootPin.sha256
$sourceFreeze.AcceptedSdkOnlyMetadataDelta=@($sourceFreeze.AcceptedSdkOnlyMetadataDelta)+$sourceChanged
$sourceFreezePath=Join-Path $phase 'source-build-inputs-after-sdk-config.json'
WriteNew $sourceFreezePath $sourceFreeze

# Review every changed installed export against the previous private installation.
$previous=ReadJson (Join-Path $ar 'sdk-profile-install-attempt3\frozen-install-inputs.json')
$rebasedInputs=@(); $metadataChanges=@()
foreach($entry in $previous.inputs) {
    $actual=Pin $entry.path
    if($actual.sha256 -cne $entry.sha256 -or $actual.bytes -ne $entry.bytes) {
        if($actual.path -ieq (Join-Path $repo 'cmake\Platform\Common\Install_common.cmake')) {
            if($entry.sha256 -cne '3830B3D226EEC3F9D133F5C2FE63958136C14D211E1A0BE31E213930F1553B21' -or $actual.sha256 -cne '68127B0ED707885E71F3B7ED6C22AA359E9A065A81735CB50E63B8F1B3573EC3') { throw 'Unexpected install generator delta' }
            $metadataChanges += [pscustomobject]@{path=$actual.path;before=$entry.sha256;after=$actual.sha256;review='Exclude only configured project roots from SDK engine external_subdirectories; source composition and dependencies preserved.'}
        } elseif($actual.path -ieq (Join-Path $build 'cmake\engine.json')) {
            $oldPath=Join-Path $phase 'generated-engine-before.json'
            if((Get-FileHash -LiteralPath $oldPath).Hash -cne $entry.sha256) { throw 'Previous engine metadata does not match freeze' }
            $old=ReadJson $oldPath; $new=ReadJson $actual.path
            if(@($old.external_subdirectories | Where-Object { $_ -ceq 'Projects/JEEditorFixture' }).Count -ne 1) { throw 'Expected one project root in previous SDK engine metadata' }
            $old.external_subdirectories=@($old.external_subdirectories | Where-Object { $_ -cne 'Projects/JEEditorFixture' })
            if(($old | ConvertTo-Json -Depth 20 -Compress) -cne ($new | ConvertTo-Json -Depth 20 -Compress)) { throw 'SDK engine metadata changed beyond removing the project root' }
            $metadataChanges += [pscustomobject]@{path=$actual.path;before=$entry.sha256;after=$actual.sha256;review='Generated engine JSON removes only Projects/JEEditorFixture; all other fields and dependency entries preserved.'}
        } elseif($actual.path.StartsWith((Join-Path $build 'install')+'\',[StringComparison]::OrdinalIgnoreCase) -and $actual.path.EndsWith('\permutation.cmake',[StringComparison]::OrdinalIgnoreCase)) {
            $relative=[IO.Path]::GetRelativePath((Join-Path $build 'install'),$actual.path)
            $oldPath=Join-Path (Join-Path $ar 'sdk-profile-install-attempt3\prefix') $relative
            $old=[IO.File]::ReadAllText($oldPath); $new=[IO.File]::ReadAllText($actual.path)
            if((Get-FileHash -LiteralPath $oldPath).Hash -cne $entry.sha256) { throw "Old export does not match freeze: $relative" }
            $oldSemantic=[regex]::Replace($old,'\s+','')
            $newSemantic=[regex]::Replace($new,'\s+','')
            $kind='Whitespace-only: unset NOTFOUND property leaves no fake include.'
            if($oldSemantic -cne $newSemantic) {
                if($relative -ine 'Code\3rdParty\sqlite\Platform\Windows\Default\permutation.cmake' -or $oldSemantic.Replace('../../../../Dependencies/sqlite-amalgamation-3530400','ExternalHeaders/sqlite-amalgamation-3530400-c4a6d33d') -cne $newSemantic) { throw "Unreviewed export semantic change: $relative" }
                $kind='SQLite external public include maps to the owned ExternalHeaders folder; all other export semantics identical.'
            }
            if($new.Contains('include_directories-NOTFOUND')) { throw "Fake include remains: $relative" }
            $metadataChanges += [pscustomobject]@{path=$actual.path;before=$entry.sha256;after=$actual.sha256;relative=$relative;review=$kind}
        } else { throw "Unreviewed install input delta: $($actual.path)" }
    }
    $rebasedInputs += $actual
}

# Reuse the audited include closure only after checking every current include.
$oldAudit=ReadJson (Join-Path $ar 'profile-full-install-script-audit-rev1.json')
$scripts=@($oldAudit.pins | ForEach-Object { Pin $_.path })
$knownScripts=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($script in $scripts) { [void]$knownScripts.Add($script.path) }
$destinations=@(); $networkDirectives=@(); $unknownIncludes=@()
foreach($script in $scripts) {
    $text=[IO.File]::ReadAllText($script.path)
    if($text -match '(?im)^\s*(?:file\(\s*(?:DOWNLOAD|UPLOAD)|FetchContent_|ExternalProject_)') { $networkDirectives += $script.path }
    foreach($inc in [regex]::Matches($text,'(?m)^\s*include\("([^"$]+)"\)')) {
        $includePath=[IO.Path]::GetFullPath($inc.Groups[1].Value)
        if(-not $knownScripts.Contains($includePath)) { $unknownIncludes += $includePath }
    }
    $rules=[regex]::Matches($text,'(?m)^\s*file\(INSTALL\s+DESTINATION\s+"([^"]+)"')
    if($rules.Count -ne [regex]::Matches($text,'(?m)^\s*file\(INSTALL\b').Count) { throw "Unsupported install rule form: $($script.path)" }
    foreach($rule in $rules) {
        $literal=$rule.Groups[1].Value
        $expanded=$literal.Replace('${CMAKE_INSTALL_PREFIX}',$prefix).Replace('${CMAKE_INSTALL_CONFIG_NAME}','profile')
        if($expanded.Contains('$')) { throw "Unresolved install destination: $literal" }
        $normalized=[IO.Path]::GetFullPath($expanded)
        $contained=$normalized -ieq $prefix -or $normalized.StartsWith($prefix+'\',[StringComparison]::OrdinalIgnoreCase)
        $destinations += [pscustomobject]@{script=$script.path;literal=$literal;normalized=$normalized;contained=$contained}
        if(-not $contained) { throw "Install destination escapes SDK prefix: $normalized" }
    }
}
if($networkDirectives.Count -or $unknownIncludes.Count) { throw 'Unexpected network directive or generated include closure delta' }
$badExports=@(Get-ChildItem -LiteralPath (Join-Path $build 'install') -Filter '*.cmake' -File -Recurse | Where-Object { [IO.File]::ReadAllText($_.FullName).Contains('ExternalHeaders/include_directories-NOTFOUND') })
if($badExports.Count) { throw 'Fake NOTFOUND external headers remain' }
$auditPath=Join-Path $phase 'normalized-install-script-audit.json'
WriteNew $auditPath ([ordered]@{utc=[DateTime]::UtcNow.ToString('o');owner='root';status='NORMALIZED_DESTINATIONS_CONTAINED';pins=$scripts;scriptCount=$scripts.Count;destinations=$destinations;destinationCount=$destinations.Count;unknownIncludes=$unknownIncludes;networkDirectives=$networkDirectives;fakeNotFoundExports=$badExports;metadataChanges=$metadataChanges;effects='Release-only source cache copy/tar/remove excluded by Profile. D3D12MemoryAllocator old export cleanup stays under fresh prefix. Runtime copy helper uses prefix bin/Windows/profile/Default. original-engine/install_manifest.txt is the only expected outside-prefix write.'})

foreach($header in @('F:\JericoEngine\Dependencies\sqlite-amalgamation-3530400\sqlite3.h','F:\JericoEngine\Dependencies\sqlite-amalgamation-3530400\sqlite3ext.h', (Join-Path $repo 'python\requirements-build.txt'), 'F:\JericoEngine\JericoEngine\build\n0-validation\original-engine-deps\packages\vulkan-validationlayers-1.3.261-je-rev1-windows\vulkan-validationlayers\lib\release\VkLayer_khronos_validation.dll','F:\JericoEngine\JericoEngine\build\n0-validation\original-engine-deps\packages\vulkan-validationlayers-1.3.261-je-rev1-windows\vulkan-validationlayers\lib\release\VkLayer_khronos_validation.json')) {
    if(-not ($rebasedInputs.path -contains $header)) { $rebasedInputs += Pin $header }
}
$os=Get-CimInstance Win32_OperatingSystem
$ram=[math]::Round((1-$os.FreePhysicalMemory/$os.TotalVisibleMemorySize)*100,2)
$jobs=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cmake.exe','MSBuild.exe','cl.exe','link.exe','Editor.exe','AssetProcessor.exe','AssetBuilder.exe','AzTestRunner.exe') })
if($ram -ge 80 -or $jobs.Count -or $env:DESTDIR -or (Test-Path -LiteralPath $installPhase)) { throw 'Install resource/ownership/fresh-prefix guard failed' }
New-Item -ItemType Directory -Path $installPhase | Out-Null
$previous.utc=[DateTime]::UtcNow.ToString('o')
$previous.argv=@('--install',$build,'--config','profile','--prefix',$prefix)
$previous.prefix=$prefix
$previous.inputs=$rebasedInputs
$previous.inputCount=$rebasedInputs.Count
$previous.sourceBuildFreeze=$sourceFreezePath
$previous.sourceBuildFreezeSHA256=(Get-FileHash -LiteralPath $sourceFreezePath).Hash
$previous.auditReview=$auditPath
$previous.auditReviewSHA256=(Get-FileHash -LiteralPath $auditPath).Hash
$previous.RAM=$ram
$previous.AcceptedGeneratedMetadataChanges=$metadataChanges
WriteNew (Join-Path $installPhase 'frozen-install-inputs.json') $previous
[ordered]@{status='FULL_PROFILE_INSTALL_ATTEMPT4_PREPARED_NOT_RUN';optionsMatched=$baseline.Count;sourceInputs=$sourceFreeze.SourceInputCount;projects=$sourceFreeze.ProjectCount;outputs=$buildResult.outputFiles.Count;metadataChanges=$metadataChanges.Count;scripts=$scripts.Count;normalizedDestinations=$destinations.Count;installInputCount=$rebasedInputs.Count;prefix=$prefix;ramPercent=$ram} | ConvertTo-Json
