$ErrorActionPreference = 'Stop'
$evidence = 'F:\JericoEngine\JericoEngine\build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-profile-import-smoke-attempt5'
$recipePath = Join-Path $evidence 'configure-argv-preparation.json'
$recipe = Get-Content -LiteralPath $recipePath -Raw | ConvertFrom-Json
$preflight = Get-Content -LiteralPath (Join-Path $evidence 'preflight.json') -Raw | ConvertFrom-Json
if (!$preflight.gate) { throw 'Consumer preflight gate was not true.' }
if (Test-Path -LiteralPath $recipe.binary) { throw 'Private consumer build directory was no longer absent.' }
$psi = [Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $recipe.executable
$psi.WorkingDirectory = [IO.Path]::GetDirectoryName($recipe.sourcePins[0].path)
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.Environment['MSBUILDDISABLENODEREUSE'] = '1'
foreach ($arg in $recipe.argv) { [void]$psi.ArgumentList.Add([string]$arg) }
$startedUtc = [DateTime]::UtcNow.ToString('o')
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
$process = [Diagnostics.Process]::new()
$process.StartInfo = $psi
if (!$process.Start()) { throw 'CMake consumer configure did not start.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$start = [pscustomobject]@{startedUtc=$startedUtc;pid=$process.Id;executable=$psi.FileName;argv=@($recipe.argv);workingDirectory=$psi.WorkingDirectory;creationUtc=$process.StartTime.ToUniversalTime().ToString('o');recipeSHA256=(Get-FileHash -LiteralPath $recipePath -Algorithm SHA256).Hash;sdkPrefix=$recipe.prefix;privateBinary=$recipe.binary;nodeReuseEnv=$psi.Environment['MSBUILDDISABLENODEREUSE']}
$start | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'configure-start.json') -Encoding utf8
$process.WaitForExit()
$nativeExit = $process.ExitCode
[IO.File]::WriteAllText((Join-Path $evidence 'configure-native-exit.txt'), [string]$nativeExit)
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText((Join-Path $evidence 'configure-stdout.log'), $stdout)
[IO.File]::WriteAllText((Join-Path $evidence 'configure-stderr.log'), $stderr)
$stopwatch.Stop()
$result = [pscustomobject]@{startedUtc=$startedUtc;completedUtc=[DateTime]::UtcNow.ToString('o');pid=$process.Id;nativeExit=$nativeExit;elapsedSeconds=[math]::Round($stopwatch.Elapsed.TotalSeconds,3);stdoutBytes=[Text.Encoding]::UTF8.GetByteCount($stdout);stderrBytes=[Text.Encoding]::UTF8.GetByteCount($stderr);stdoutSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'configure-stdout.log') -Algorithm SHA256).Hash;stderrSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'configure-stderr.log') -Algorithm SHA256).Hash}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'configure-result.json') -Encoding utf8
Write-Output ("CONFIGURE_NATIVE_EXIT=" + $nativeExit)
Write-Output ("CONFIGURE_PID=" + $process.Id)
Write-Output ("ELAPSED_SECONDS=" + $result.elapsedSeconds)
