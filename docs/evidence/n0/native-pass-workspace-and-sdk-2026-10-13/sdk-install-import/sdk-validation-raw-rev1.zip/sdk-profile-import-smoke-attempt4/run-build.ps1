$ErrorActionPreference = 'Stop'
$evidence = 'F:\JericoEngine\JericoEngine\build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-profile-import-smoke-attempt4'
$recipe = Get-Content -LiteralPath (Join-Path $evidence 'configure-argv-preparation.json') -Raw | ConvertFrom-Json
$preflight = Get-Content -LiteralPath (Join-Path $evidence 'preflight-reconciled.json') -Raw | ConvertFrom-Json
if (!$preflight.gate) { throw 'Consumer preflight gate was not true.' }
if ([int](Get-Content -LiteralPath (Join-Path $evidence 'configure-native-exit.txt') -Raw) -ne 0) { throw 'Configure did not exit zero.' }
$psi = [Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $recipe.executable
$psi.WorkingDirectory = $recipe.binary
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.Environment['MSBUILDDISABLENODEREUSE'] = '1'
foreach ($arg in @('--build', $recipe.binary, '--config', 'profile', '--target', 'JENativeSdkConsumer', '--parallel', '1', '--', '/nr:false', '/p:CL_MPCount=1')) { [void]$psi.ArgumentList.Add([string]$arg) }
$argv = @('--build', $recipe.binary, '--config', 'profile', '--target', 'JENativeSdkConsumer', '--parallel', '1', '--', '/nr:false', '/p:CL_MPCount=1')
$startedUtc = [DateTime]::UtcNow.ToString('o')
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
$process = [Diagnostics.Process]::new()
$process.StartInfo = $psi
if (!$process.Start()) { throw 'Consumer native build did not start.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$start = [pscustomobject]@{startedUtc=$startedUtc;pid=$process.Id;executable=$psi.FileName;argv=$argv;workingDirectory=$psi.WorkingDirectory;creationUtc=$process.StartTime.ToUniversalTime().ToString('o');recipeSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'configure-argv-preparation.json') -Algorithm SHA256).Hash;sdkPrefix=$recipe.prefix;nodeReuseEnv=$psi.Environment['MSBUILDDISABLENODEREUSE']}
$start | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'build-start.json') -Encoding utf8
$process.WaitForExit()
$nativeExit = $process.ExitCode
[IO.File]::WriteAllText((Join-Path $evidence 'build-native-exit.txt'), [string]$nativeExit)
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText((Join-Path $evidence 'build-stdout.log'), $stdout)
[IO.File]::WriteAllText((Join-Path $evidence 'build-stderr.log'), $stderr)
$stopwatch.Stop()
$result = [pscustomobject]@{startedUtc=$startedUtc;completedUtc=[DateTime]::UtcNow.ToString('o');pid=$process.Id;nativeExit=$nativeExit;elapsedSeconds=[math]::Round($stopwatch.Elapsed.TotalSeconds,3);stdoutBytes=[Text.Encoding]::UTF8.GetByteCount($stdout);stderrBytes=[Text.Encoding]::UTF8.GetByteCount($stderr);stdoutSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'build-stdout.log') -Algorithm SHA256).Hash;stderrSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'build-stderr.log') -Algorithm SHA256).Hash}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'build-result.json') -Encoding utf8
Write-Output ("BUILD_NATIVE_EXIT=" + $nativeExit)
Write-Output ("BUILD_PID=" + $process.Id)
Write-Output ("ELAPSED_SECONDS=" + $result.elapsedSeconds)
