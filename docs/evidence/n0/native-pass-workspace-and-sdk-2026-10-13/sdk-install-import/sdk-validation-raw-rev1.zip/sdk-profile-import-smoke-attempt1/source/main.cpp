#include <JE/Editor/Materials/MaterialsRegistration.h>
#include <JE/Editor/Camera/CameraModule.h>
#include <JE/Editor/RenderIntegration/RenderIntegrationModule.h>
#include <cstdio>

int main()
{
    using NativeModuleFactory = AZ::Module* (*)();
    NativeModuleFactory volatile factories[] = {
        &JE::Editor::CreateMaterialsModule,
        &JE::Editor::Camera::CreateAuthoringModule,
        &JE::Editor::RenderIntegration::CreateAuthoringModule
    };
    for (auto& factory : factories)
    {
        if (factory == nullptr)
        {
            return 1;
        }
    }
    std::puts("JE SDK: Materials, Camera and RenderIntegration exports resolved.");
    return 0;
}