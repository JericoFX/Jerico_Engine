param(
    [Parameter(Mandatory)][string]$BuildRoot,
    [Parameter(Mandatory)][string]$RootInstallSHA256,
    [Parameter(Mandatory)][string]$ResultPath
)
$ErrorActionPreference = 'Stop'
$build = [IO.Path]::GetFullPath($BuildRoot).TrimEnd('/','\').Replace('\','/')
$root = Join-Path $build 'cmake_install.cmake'
if ((Get-FileHash -LiteralPath $root).Hash -ine $RootInstallSHA256) { throw 'Root install input SHA mismatch' }
if (Test-Path -LiteralPath $ResultPath) { throw 'Result already exists' }
$failures = [Collections.Generic.List[string]]::new()
$inputs = [Collections.Generic.Dictionary[string,object]]::new([StringComparer]::OrdinalIgnoreCase)
function ReadPinned([string]$path) {
    $full = [IO.Path]::GetFullPath($path)
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Referenced file missing: $full" }
    $file = Get-Item -LiteralPath $full
    $inputs[$full] = [ordered]@{path=$full;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $full).Hash}
    return [IO.File]::ReadAllText($full)
}
function Check([bool]$condition, [string]$diagnostic) { if (-not $condition) { $failures.Add($diagnostic) } }
$content = ReadPinned $root
$files = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$installMatches = [regex]::Matches($content, '(?m)^\s*file\(INSTALL\b(?:"[^"]*"|[^()"])*\)')
if ($installMatches.Count -ne [regex]::Matches($content, '(?m)^\s*file\(INSTALL\b').Count) {
    throw 'Unsupported file(INSTALL) form; reader must not omit a rule'
}
$installs = @()
foreach ($installMatch in $installMatches) {
    $block = $installMatch.Value.Trim()
    $installs += $block
    if ($block -match '(?s)\bFILES\s+(.+)\)\s*$') {
        foreach ($match in [regex]::Matches($Matches[1], '"([^"]+)"')) { [void]$files.Add($match.Groups[1].Value) }
    }
}
$legacyExe = @($installs | Where-Object { $_ -match 'TYPE EXECUTABLE.*(?:MaterialEditor|MaterialCanvas|PassCanvas)\.exe"' })
Check ($legacyExe.Count -eq 0) "Legacy executable install rules remain: $($legacyExe.Count)"
$smc = @($installs | Where-Object { $_ -match 'TYPE EXECUTABLE.*ShaderManagementConsole\.exe"' })
Check ($smc.Count -eq 3) "Expected unchanged SMC three-config rules, got $($smc.Count)"
$exports = @($files | Where-Object { $_ -match '/permutation\.cmake$' })
$exportData = @()
$forbidden = @()
foreach ($path in $exports) {
    $text = ReadPinned $path
    $exportData += [pscustomobject]@{path=$path;text=$text}
    if ($text -match '\bNAME\s+(?:MaterialEditor|MaterialCanvas|PassCanvas)\s+IMPORTED\b' -or
        $text -match '\bGem::(?:MaterialEditor|MaterialCanvas|PassCanvas)(?![\w.])' -or
        $text -match '(?s)ly_set_gem_variant_to_load\([^)]*\b(?:MaterialEditor|MaterialCanvas|PassCanvas)\b' -or
        $text -match '(?s)(?:ly_enable_gems|o3de_add_variant_dependencies_for_gem_dependencies)\([^)]*\b(?:MaterialEditor|MaterialCanvas|PassCanvas)\b') {
        $forbidden += $path
    }
    foreach ($alias in [regex]::Matches($text, '(?s)ly_create_alias\([^)]*\bNAME\s+(?:MaterialEditor|MaterialCanvas|PassCanvas)\.Builders\b[^)]*\)')) {
        Check ($alias.Value -match '\bTARGETS\s*\)$') "Nonempty legacy Builders alias in $path"
    }
}
Check ($forbidden.Count -eq 0) 'Forbidden legacy executable target/variant/dependency in a referenced export'
$nativeOwners = @()
foreach ($owner in @(
    @{name='EditorMaterials';relative='Editor/Materials'},
    @{name='EditorCamera';relative='Editor/Camera'},
    @{name='EditorRenderIntegration';relative='Editor/Render/Integration'}
)) {
    $matches = @($exportData | Where-Object { $_.text -match "\bNAME\s+$($owner.name)\s+IMPORTED\b" })
    Check ($matches.Count -eq 1) "Native owner $($owner.name) has $($matches.Count) referenced definitions"
    $expected = "$build/install/$($owner.relative)/Platform/Windows/Default/permutation.cmake".Replace('\','/')
    if ($matches.Count -eq 1) {
        Check ($matches[0].path.Replace('\','/') -ieq $expected) "Native owner export path mismatch: $($owner.name)"
        Check ($matches[0].text -match '\bNAMESPACE\s+JE\b') "Native owner JE namespace missing: $($owner.name)"
    }
    $configs = @()
    foreach ($config in @('debug','profile','release')) {
        $configFile = "$build/install/$($owner.relative)/Platform/Windows/Default/$($owner.name)_$config.cmake"
        Check ($files.Contains($configFile)) "Native owner config not root-manifest referenced: $configFile"
        if ($files.Contains($configFile)) { [void](ReadPinned $configFile); $configs += $configFile }
    }
    $nativeOwners += [ordered]@{target="JE::$($owner.name)";expectedPath=$expected;referencedDefinitions=$matches.Count;configs=$configs}
}
$loaderFiles = @($files | Where-Object { $_ -match '/Default/o3de_subdirectories_windows\.cmake$' })
Check ($loaderFiles.Count -eq 1) "Expected one referenced DEFAULT loader, got $($loaderFiles.Count)"
$loaderPaths = @()
if ($loaderFiles.Count -eq 1) {
    $loader = ReadPinned $loaderFiles[0]
    Check ($loader -notmatch 'add_subdirectory\("\."\)') 'Loader still contains add_subdirectory(dot)'
    foreach ($relative in @('Editor/Materials','Editor/Camera','Editor/Render/Integration')) {
        $count = [regex]::Matches($loader, 'add_subdirectory\("' + [regex]::Escape($relative) + '"\)').Count
        Check ($count -eq 1) "Native loader path $relative occurs $count times"
        $loaderPaths += [ordered]@{path=$relative;count=$count}
    }
}
$legacyLocationExports = @($files | Where-Object { $_ -match '/(?:MaterialEditor|MaterialCanvas|PassCanvas)_(?:debug|profile|release)\.cmake$' })
Check ($legacyLocationExports.Count -eq 0) 'Legacy executable config-location exports still referenced'
$engineScripts = @([regex]::Matches($content, 'include\("([^"]*/Engine/cmake_install\.cmake)"\)') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
Check ($engineScripts.Count -eq 1) "Root references $($engineScripts.Count) Engine install scripts"
$assetsScripts = @()
if ($engineScripts.Count -eq 1) {
    $engineInstall = ReadPinned $engineScripts[0]
    $assetsScripts = @([regex]::Matches($engineInstall, 'include\("([^"]*/Engine/Editor/Materials/cmake_install\.cmake)"\)') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
}
Check ($assetsScripts.Count -eq 1) "Native material assets install script count=$($assetsScripts.Count)"
if ($assetsScripts.Count -eq 1) {
    $assetText = ReadPinned $assetsScripts[0]
    foreach ($suffix in @('Assets','Preview/Assets','RenderPass/Assets')) {
        Check ($assetText.Contains("/Editor/Materials/$suffix")) "Native assets install rule missing: $suffix"
    }
}
$compatProjects = @()
foreach ($hostName in @('MaterialEditor','MaterialCanvas','PassCanvas')) {
    $hostRoots = @([regex]::Matches($content, 'include\("([^"]*/External/' + $hostName + '-[^/]+/cmake_install\.cmake)"\)') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
    Check ($hostRoots.Count -eq 1) "Root references $($hostRoots.Count) explicit source compatibility roots for $hostName"
    if ($hostRoots.Count -eq 1) {
        $hostInstall = ReadPinned $hostRoots[0]
        $codeScript = Join-Path ([IO.Path]::GetDirectoryName($hostRoots[0])) 'Code/cmake_install.cmake'
        Check ($hostInstall.Replace('\','/').Contains($codeScript.Replace('\','/'))) "Compatibility Code install script not parent-referenced: $hostName"
        $path = Join-Path ([IO.Path]::GetDirectoryName($codeScript)) "$hostName.vcxproj"
        Check (Test-Path -LiteralPath $path -PathType Leaf) "Explicit source compatibility target missing: $hostName"
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            [void](ReadPinned $path)
            $compatProjects += $path
        }
    }
}
# Runtime install copy scripts are emitted into the root script as includes. Reject only exact host stems.
$legacyRuntimeIncludes = @([regex]::Matches($content, 'include\("([^"]*(?:MaterialEditor|MaterialCanvas|PassCanvas)\.cmake)"\)') | ForEach-Object { $_.Groups[1].Value })
Check ($legacyRuntimeIncludes.Count -eq 0) 'Legacy standalone runtime-copy install include remains'
foreach ($entry in $inputs.Values) { if ((Get-FileHash -LiteralPath $entry.path).Hash -cne $entry.sha256) { throw "Input drift: $($entry.path)" } }
$result = [ordered]@{
    status= $(if($failures.Count){'GENERATED_CONFIG_CHECK_FAILED'}else{'GENERATED_CONFIG_CHECK_PASSED_NOT_SDK_ACCEPTANCE'})
    rootInstall=$root;rootInstallSHA256=$RootInstallSHA256;referencedExportCount=$exports.Count
    legacyExeRules=$legacyExe;legacyConfigExports=$legacyLocationExports;legacyRuntimeIncludes=$legacyRuntimeIncludes
    forbiddenActiveExports=$forbidden;nativeOwners=$nativeOwners;loaderPaths=$loaderPaths
    smcExecutableRules=$smc.Count;nativeAssetsScripts=$assetsScripts;explicitCompatibilityProjects=$compatProjects
    failures=@($failures);inputs=@($inputs.Values);capturedUtc=[DateTime]::UtcNow.ToString('o')
    limitation='Reads generated configuration only. Does not install SDK, prove all binary payloads exist, configure a consumer, link or run any product.'
}
$stream=[IO.File]::Open($ResultPath,[IO.FileMode]::CreateNew)
try { $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($result|ConvertTo-Json -Depth 8));$stream.Write($bytes,0,$bytes.Length) } finally { $stream.Dispose() }
if($failures.Count) { throw ($failures -join '; ') }
