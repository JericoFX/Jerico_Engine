$ErrorActionPreference = 'Stop'
$evidence = 'F:\JericoEngine\JericoEngine\build\n0-validation\native-passgraph-workspace-rev1\sdk-legacy-install-analysis-rev1\sdk-profile-configure-attempt6'
$repo = 'F:\JericoEngine\JericoEngine'
$freezePath = Join-Path $evidence 'frozen-configure-inputs.json'
$freeze = Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
$preflight = Get-Content -LiteralPath (Join-Path $evidence 'preflight.json') -Raw | ConvertFrom-Json
if (!$preflight.gate) { throw 'Preflight gate was not true.' }
$psi = [Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $freeze.executable
$psi.WorkingDirectory = $repo
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.Environment['MSBUILDDISABLENODEREUSE'] = '1'
foreach ($arg in $freeze.argv) { [void]$psi.ArgumentList.Add([string]$arg) }
$startUtc = [DateTime]::UtcNow.ToString('o')
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
$process = [Diagnostics.Process]::new()
$process.StartInfo = $psi
if (!$process.Start()) { throw 'CMake process did not start.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$startRecord = [pscustomobject]@{startUtc=$startUtc;pid=$process.Id;executable=$psi.FileName;argv=@($freeze.argv);workingDirectory=$psi.WorkingDirectory;creationUtc=$process.StartTime.ToUniversalTime().ToString('o');freezeSHA256=(Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash;cacheSHA256=(Get-FileHash -LiteralPath (Join-Path $repo 'build\n0-validation\original-engine\CMakeCache.txt') -Algorithm SHA256).Hash;nodeReuseEnv=$psi.Environment['MSBUILDDISABLENODEREUSE']}
$startRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'configure-start.json') -Encoding utf8
$process.WaitForExit()
$nativeExit = $process.ExitCode
[IO.File]::WriteAllText((Join-Path $evidence 'native-exit.txt'), [string]$nativeExit)
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText((Join-Path $evidence 'configure-stdout.log'), $stdout)
[IO.File]::WriteAllText((Join-Path $evidence 'configure-stderr.log'), $stderr)
$stopwatch.Stop()
$result = [pscustomobject]@{startUtc=$startUtc;endUtc=[DateTime]::UtcNow.ToString('o');pid=$process.Id;exit=$nativeExit;elapsedSeconds=[math]::Round($stopwatch.Elapsed.TotalSeconds,3);stdoutBytes=[Text.Encoding]::UTF8.GetByteCount($stdout);stderrBytes=[Text.Encoding]::UTF8.GetByteCount($stderr);stdoutSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'configure-stdout.log') -Algorithm SHA256).Hash;stderrSHA256=(Get-FileHash -LiteralPath (Join-Path $evidence 'configure-stderr.log') -Algorithm SHA256).Hash}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'configure-result.json') -Encoding utf8
Write-Output ("CMAKE_NATIVE_EXIT=" + $nativeExit)
Write-Output ("CMAKE_PID=" + $process.Id)
Write-Output ("ELAPSED_SECONDS=" + $result.elapsedSeconds)
