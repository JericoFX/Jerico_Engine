param([switch]$Execute,[string]$RecipeSHA256)
$ErrorActionPreference='Stop'
if(!$Execute){'PREPARED_NOT_RUN: incremental consumer only, then positive and negative once.';return}
$recipePath="$PSScriptRoot/recipe-attempt5.json"
if($RecipeSHA256 -cnotmatch '^[0-9A-F]{64}$' -or (Get-FileHash -LiteralPath $recipePath).Hash -cne $RecipeSHA256){throw 'Reviewed rev5 recipe pin required'}
$five=Get-Content -Raw -LiteralPath $recipePath|ConvertFrom-Json
foreach($pin in $five.pins){if((Get-Item -LiteralPath $pin.path).Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $pin.path).Hash -cne $pin.sha256){throw 'Rev5 fixed input drift'}}
$plan=Get-Content -Raw -LiteralPath $five.stagePlan.path|ConvertFrom-Json
$text=[IO.File]::ReadAllText($five.stageRunner.path)
$first=$text.IndexOf('$run4=$plan.run4.path',[StringComparison]::Ordinal);$last=$text.IndexOf('if(!$Stage){',[StringComparison]::Ordinal)
if($first -lt 0 -or $last -le $first){throw 'Approved stage87 initialization anchors changed'}
. ([scriptblock]::Create($text.Substring($first,$last-$first)))
$review=Json $five.sdkReview.path
if(!$review.approved -or $review.reviewer -cne '/root' -or !$review.exportsImportsUnchanged -or $review.freezeSHA256 -cne $plan.freeze87.sha256){throw 'Actual parent SDK87 approval required'}
Verify @($review.sdkInventory,$review.stageReceipt,$review.apiReport)
$recipe.sourcePins=$five.sourcePins;$recipe.sdkInventory=$review.sdkInventory
$expected=@(Json $recipe.sdkInventory.path)
$FreezePath=$plan.freeze87.path;$FreezeSHA256=$plan.freeze87.sha256
$SnapshotPath=$five.snapshotRoot
function VerifySnapshot {
    Verify @($five.snapshotReceipt)
    $s=Json $five.snapshotReceipt.path
    if($s.schema -cne 'je-shader-runtime87-short-snapshot-v1' -or $s.state -cne 'SNAPSHOT_COMPLETE_NOT_RUNTIME_ACCEPTANCE' -or $s.payloads -ne 15 -or $s.runtimeAssets -ne 6 -or $s.catalog.sha256 -cne '745CB10B631D8B7464102C989D826CC8A9ECF4D48315C41B13021FB523DBFB46' -or $s.manifest.sha256 -cne '01EC31D14123965AEEFAA9756684024876DAD079732E37187FDD3C183A1EFD96' -or [IO.Path]::GetFullPath($s.root) -ine [IO.Path]::GetFullPath($SnapshotPath) -or [IO.Path]::GetFullPath($SnapshotPath) -ine [IO.Path]::GetFullPath('F:/JericoEngine/JericoEngine/build/sdk-vk-shader87-data')){throw 'Exact approved short snapshot required'}
    AssertNoReparse87 $SnapshotPath
    $root=[IO.Path]::GetFullPath($SnapshotPath).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($p in @($s.catalog,$s.manifest)+@($s.products)){
        $full=[IO.Path]::GetFullPath($p.path)
        if(!$full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or !$seen.Add($full)){throw 'Duplicate/escaping short snapshot path'}
        AssertNoReparse87 $full
    }
    foreach($p in $s.products){if([IO.Path]::GetFullPath($p.path) -ine [IO.Path]::GetFullPath((Join-Path "$SnapshotPath/products" $p.productName))){throw 'ProductName mount differs'}}
    if(@(Get-ChildItem -LiteralPath $SnapshotPath -Recurse -File).Count -ne $seen.Count -or $seen.Count -ne $s.materializedFiles){throw 'Short snapshot membership changed'}
    Verify @($s.catalog,$s.manifest);Verify $s.products
    $manifest=Json $s.manifest.path
    if(@($manifest.assets).Count -ne 6){throw 'Six runtime roles required'}
    foreach($asset in $manifest.assets){
        $full=Join-Path "$SnapshotPath/products/pc" $asset.productPath
        $row=@($s.products|Where-Object{$_.productName -ceq ('pc/'+$asset.productPath) -and $_.guid -ieq $asset.guid -and $_.subId -eq $asset.subId -and $_.type -ieq $asset.type})
        if($full.Length -ge 260 -or $row.Count -ne 1 -or [IO.Path]::GetFullPath($row[0].path) -ine [IO.Path]::GetFullPath($full)){throw 'Runtime role path/identity does not match short mount'}
    }
    return $s
}
$out=$five.outputDirectory
if(Test-Path -LiteralPath $out){throw 'New exclusive attempt5 output required'}
AssertNoReparse87 $PSScriptRoot;AssertNoReparse87 $recipe.consumerBuild
Assert-NoNative;NativeAdmission
VerifyEngine87;VerifyInventory87 $expected;VerifyProtected;Verify $five.sourcePins;Verify $five.initialBinaries;VerifySnapshot|Out-Null
New-Item -ItemType Directory -Path $out -ErrorAction Stop|Out-Null
Save 'preflight.json' @{recipe=(Pin $recipePath);freeze=$plan.freeze87;sdk=$review.sdkInventory;source=$five.sourcePins;snapshot=$five.snapshotReceipt;configure=$false;engineBuild=$false;install=$false}
$failure=$null;$postFailure=$null;$compiledPins=@()
try{
    Run 'build-consumer' $recipe.cmake $recipe.buildArgv $recipe.sourceRoot
    $compiledPins=@((Pin $recipe.consumerExecutable),(Pin ([IO.Path]::ChangeExtension($recipe.consumerExecutable,'.pdb'))))
    Save 'consumer-built-pins.json' $compiledPins
    Verify $five.sourcePins;VerifyInventory87 $expected
    $snapshot=VerifySnapshot
    $original=[IO.File]::ReadAllText($run4)
    $first=$original.IndexOf('    $exe=$recipe.consumerExecutable',[StringComparison]::Ordinal)
    $last=$original.IndexOf('} catch {$fatal=$_.Exception.Message;throw} finally {',[StringComparison]::Ordinal)
    if($first -lt 0 -or $last -le $first){throw 'Exact Run4 runtime oracle block missing'}
    . ([scriptblock]::Create($original.Substring($first,$last-$first)))
}catch{$failure=$_.Exception.Message;throw}finally{
    try{Verify $five.pins;Verify $five.sourcePins;Verify $compiledPins;VerifyEngine87;VerifyInventory87 $expected;VerifyProtected;VerifySnapshot|Out-Null;Assert-NoNative}catch{$postFailure=$_.Exception.Message}
    Save 'postflight.json' @{failure=$failure;postflightFailure=$postFailure;allPostflightChecksPassed=($null -eq $postFailure);observedIdentities=$script:cleanupResults;sourceCount=14034;sdkCount=11218;protected=40;owner=26;payloads=15;runtimeAssets=6;parentAcceptanceRequired=$true;limits='No visual/Gem/globalAP/VR/Linux/Shipping acceptance'}
    if($postFailure){throw "Postflight failed: $postFailure"}
}
