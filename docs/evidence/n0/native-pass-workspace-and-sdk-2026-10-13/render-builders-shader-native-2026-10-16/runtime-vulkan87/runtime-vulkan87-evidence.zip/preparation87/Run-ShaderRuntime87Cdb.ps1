param([switch]$Execute,[string]$PlanSHA256)
$ErrorActionPreference='Stop'
if(!$Execute){'PREPARED_NOT_RUN: one CDB2 diagnostic, no runtime acceptance.';return}
$path="$PSScriptRoot/cdb87-plan.json"
if($PlanSHA256 -cnotmatch '^[0-9A-F]{64}$' -or (Get-FileHash -LiteralPath $path).Hash -cne $PlanSHA256){throw 'Reviewed CDB2 plan required'}
$diag=Get-Content -Raw -LiteralPath $path|ConvertFrom-Json
foreach($pin in $diag.pins){if((Get-Item -LiteralPath $pin.path).Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $pin.path).Hash -cne $pin.sha256){throw 'CDB2 preparation drift'}}
$plan=Get-Content -Raw -LiteralPath $diag.stagePlan.path|ConvertFrom-Json
$text=[IO.File]::ReadAllText($diag.stageRunner.path)
$first=$text.IndexOf('$run4=$plan.run4.path',[StringComparison]::Ordinal);$last=$text.IndexOf('if(!$Stage){',[StringComparison]::Ordinal)
if($first -lt 0 -or $last -le $first){throw 'Approved stage87 initialization anchors absent'}
. ([scriptblock]::Create($text.Substring($first,$last-$first)))
$prior=Json $diag.baseCdbPlan.path
Verify $prior.inputPins
$review=Json $diag.sdkReview.path
if(!$review.approved -or $review.reviewer -cne '/root' -or !$review.exportsImportsUnchanged -or $review.freezeSHA256 -cne $plan.freeze87.sha256){throw 'Current SDK87 approval required'}
Verify @($review.sdkInventory,$review.stageReceipt,$review.apiReport)
$recipe.sdkInventory=$review.sdkInventory;$expected=@(Json $review.sdkInventory.path)
$FreezePath=$plan.freeze87.path;$FreezeSHA256=$plan.freeze87.sha256
$positive=Json $diag.positiveStart.path
if(($diag.argv[-12..-1] -join '|') -cne ($positive.argv -join '|') -or $diag.cwd -cne $positive.cwd -or $diag.path -cne $positive.path -or [IO.Path]::GetFullPath($positive.executable) -ine [IO.Path]::GetFullPath($prior.debuggee.path)){throw 'Exact positive87 launch changed'}
$out=$diag.outputDirectory
if(Test-Path -LiteralPath $out){throw 'Exclusive new CDB2 output required'}
AssertNoReparse87 $PSScriptRoot
Assert-NoNative;NativeAdmission
if(@(Get-CimInstance Win32_Process|Where-Object Name -ceq 'cdb.exe').Count){throw 'Another debugger owner is active'}
VerifyEngine87;VerifyInventory87 $expected;VerifyProtected;VerifySnapshot|Out-Null;Verify $recipe.sourcePins;Verify $plan.consumerPins
New-Item -ItemType Directory -Path $out -ErrorAction Stop|Out-Null
Save 'preflight.json' @{plan=(Pin $path);freeze=$plan.freeze87;sdkInventory=$review.sdkInventory;positive=$diag.positiveStart;runtimeAcceptance=$false}
$oldSymbols=$env:_NT_SYMBOL_PATH;$oldAlt=$env:_NT_ALT_SYMBOL_PATH;$failure=$null;$postFailure=$null
try{
    $env:_NT_SYMBOL_PATH=$prior.localSymbols;$env:_NT_ALT_SYMBOL_PATH=''
    try{Run 'cdb-positive' $prior.cdb.path $diag.argv $diag.cwd $diag.path 180000}catch{$failure=$_.Exception.Message}
    $result=Json "$out/cdb-positive.result.json"
    Save 'diagnostic-result.json' @{rawCdbExit=$result.exitCode;failure=$failure;runtimeReady=$false;acceptance=$false;limit='Only real .lastevent/.exr and stack establish exception; command echo is not evidence'}
}finally{
    $env:_NT_SYMBOL_PATH=$oldSymbols;$env:_NT_ALT_SYMBOL_PATH=$oldAlt
    try{Verify $diag.pins;Verify $prior.inputPins;VerifyEngine87;VerifyInventory87 $expected;VerifyProtected;VerifySnapshot|Out-Null;Verify $recipe.sourcePins;Verify $plan.consumerPins;Assert-NoNative}catch{$postFailure=$_.Exception.Message}
    $remaining=@(Get-CimInstance Win32_Process|Where-Object Name -in @('cdb.exe','JENativeShaderRuntimeConsumer.exe')|Select-Object ProcessId,ExecutablePath,CreationDate,ParentProcessId)
    Save 'postflight.json' @{failure=$failure;postflightFailure=$postFailure;remainingDebuggerOrConsumer=$remaining;allPostflightChecksPassed=($null -eq $postFailure -and $remaining.Count -eq 0);observedPhaseIdentities=$script:cleanupResults;runtimeReady=$false;acceptance=$false;limit='Debugger q owns debuggee termination; no missed fast-child identity is invented'}
    if($postFailure -or $remaining.Count){throw 'CDB2 postflight/closure incomplete'}
}
if($failure){throw $failure}
