param([switch]$Execute,[ValidateSet('BuildInstall','Runtime')][string]$Stage,[string]$PlanSHA256,[string]$FreezePath,[string]$FreezeSHA256,[string]$ParentSdkReviewPath,[string]$ParentSdkReviewSHA256)
$ErrorActionPreference='Stop'
if(!$Execute){Write-Output 'PREPARED_NOT_RUN: separate build/install and runtime leases; no native operation.';return}
if($PlanSHA256 -cnotmatch '^[0-9A-F]{64}$' -or (Get-FileHash -LiteralPath "$PSScriptRoot/plan87.json").Hash -cne $PlanSHA256){throw 'Reviewed plan87 pin required'}
$plan=Get-Content -LiteralPath "$PSScriptRoot/plan87.json" -Raw|ConvertFrom-Json
if($FreezeSHA256 -cne $plan.freeze87.sha256 -or [IO.Path]::GetFullPath($FreezePath) -ine [IO.Path]::GetFullPath($plan.freeze87.path)){throw 'Exact current parent freeze87 required'}
$run4=$plan.run4.path;$base=$plan.nativeRunBase.path
foreach($pin in @($plan.run4,$plan.nativeRunBase)){if((Get-FileHash -LiteralPath $pin.path).Hash -cne $pin.sha256 -or (Get-Item -LiteralPath $pin.path).Length -ne $pin.bytes){throw 'Approved runtime86/SDK83 helper drift'}}
$tokens=$null;$errors=$null
$run4Ast=[Management.Automation.Language.Parser]::ParseFile($run4,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Run4 parser failure'}
$ast=[Management.Automation.Language.Parser]::ParseFile($base,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'SDK83 parser failure'}
$import=@($run4Ast.FindAll({param($n)$n -is [Management.Automation.Language.ForEachStatementAst]},$true)|Where-Object{$_.Extent.Text.StartsWith("foreach(`$name in @('Json'")})
if($import.Count -ne 1){throw 'Approved native function import ambiguous'}
. ([scriptblock]::Create($import[0].Extent.Text))
foreach($name in @('Record-PhaseTree','Close-PhaseOwned','Assert-NoNative','VerifySnapshot','VerifyProtected','Review-LoadedModules')){
    $definition=@($run4Ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)|Where-Object Name -ceq $name)
    if($definition.Count -ne 1){throw "Approved helper ambiguous: $name"}
    . ([scriptblock]::Create($definition[0].Extent.Text))
}
$script:owned=@{};$script:cleanupResults=@()
Verify $plan.fixedPins
$recipe=Json $plan.recipe86.path
$SnapshotPath=$recipe.snapshotPath;$SnapshotReceiptSHA256=$recipe.snapshotReceipt.sha256;$script:snapshotReceiptBytes=$recipe.snapshotReceipt.bytes
function VerifyEngine87 {
    if($FreezeSHA256 -cnotmatch '^[0-9A-F]{64}$'){throw 'Real reviewed parent freeze87 SHA required'}
    if((Pin $FreezePath).sha256 -cne $FreezeSHA256){throw 'Parent freeze87 pin changed'}
    $old=Json $recipe.freeze.path;$now=Json $FreezePath
    if(@($old.inputs).Count -ne 14034 -or @($now.inputs).Count -ne 14034){throw 'Exact14034 engine inputs required'}
    $prior=@{};foreach($p in $old.inputs){$key=[IO.Path]::GetFullPath($p.path);if($prior.ContainsKey($key)){throw 'Duplicate baseline engine input'};$prior[$key]=$p}
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase);$changes=@(foreach($p in $now.inputs){
        $key=[IO.Path]::GetFullPath($p.path);if(!$seen.Add($key) -or !$prior.ContainsKey($key)){throw 'New/duplicate engine input'}
        $before=$prior[$key];if($before.bytes -ne $p.bytes -or $before.sha256 -cne $p.sha256){$p}
    })
    if($changes.Count -ne 1 -or [IO.Path]::GetFullPath($changes[0].path) -ine [IO.Path]::GetFullPath($plan.changedEngineInput.path) -or $changes[0].bytes -ne $plan.changedEngineInput.bytes -or $changes[0].sha256 -cne $plan.changedEngineInput.sha256){throw 'Only approved Device.cpp delta allowed versus freeze86'}
    Verify $now.inputs
}
function VerifyInventory87($expected){
    $actual=@(Inventory $recipe.sdkPrefix)
    if(@($expected).Count -ne 11218 -or $actual.Count -ne 11218){throw 'SDK exact11218 membership required'}
    $map=@{};foreach($p in $expected){if($map.ContainsKey($p.relativePath)){throw 'Duplicate SDK path'};$map[$p.relativePath]=$p}
    foreach($p in $actual){$old=$map[$p.relativePath];if(!$old -or $old.bytes -ne $p.bytes -or $old.sha256 -cne $p.sha256){throw "SDK drift: $($p.relativePath)"}}
}
function AssertNoReparse87($path){
    $item=Get-Item -LiteralPath $path
    while($item){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse path forbidden'};$item=if($item -is [IO.FileInfo]){$item.Directory}else{$item.Parent}}
}
if(!$Stage){throw 'Explicit stage required'}
$out=if($Stage -ceq 'BuildInstall'){$plan.buildInstallOutput}else{$plan.runtimeOutput}
if(Test-Path -LiteralPath $out){throw 'New exclusive stage output required; no retry/overwrite'}
AssertNoReparse87 $PSScriptRoot
Assert-NoNative;NativeAdmission
VerifyEngine87;Verify $recipe.sourcePins;VerifyProtected;VerifySnapshot|Out-Null;Verify $plan.consumerPins
$expectedInventory=@(Json $recipe.sdkInventory.path)
if($Stage -ceq 'Runtime'){
    if($ParentSdkReviewSHA256 -cnotmatch '^[0-9A-F]{64}$' -or (Pin $ParentSdkReviewPath).sha256 -cne $ParentSdkReviewSHA256){throw 'Real parent SDK87/API review pin required'}
    $review=Json $ParentSdkReviewPath
    if($review.approved -isnot [bool] -or !$review.approved -or $review.reviewer -cne '/root' -or !$review.exportsImportsUnchanged -or $review.freezeSHA256 -cne $FreezeSHA256){throw 'Parent must approve actual SDK delta and exports/imports before runtime'}
    Verify @($review.sdkInventory,$review.stageReceipt,$review.apiReport)
    $stageReceipt=Json $review.stageReceipt.path
    if(!$stageReceipt.buildInstallComplete -or $stageReceipt.freezeSHA256 -cne $FreezeSHA256 -or $stageReceipt.sdkInventory.sha256 -cne $review.sdkInventory.sha256){throw 'Review must bind completed build/install87 and exact new SDK inventory'}
    $recipe.sdkInventory=$review.sdkInventory
    $expectedInventory=@(Json $recipe.sdkInventory.path)
}
VerifyInventory87 $expectedInventory
New-Item -ItemType Directory -Path $out -ErrorAction Stop|Out-Null
Save 'preflight.json' @{plan=(Pin "$PSScriptRoot/plan87.json");freeze=(Pin $FreezePath);source=14034;sdk=11218;protected=40;owner=26;snapshot=15;consumer=$plan.consumerPins;stage=$Stage}
$failure=$null;$postFailure=$null;$stageComplete=$false
try {
    if($Stage -ceq 'BuildInstall'){
        New-Item -ItemType Directory -Path "$out/before" -ErrorAction Stop|Out-Null
        foreach($row in $plan.sdkPayloads){
            $original=Join-Path $recipe.sdkPrefix $row.relativePath;AssertNoReparse87 $original;Verify @($row.before)
            $copy="$out/before/$([IO.Path]::GetFileName($original))";[IO.File]::Copy($original,$copy,$false)
            $copyPin=Pin $copy;if($copyPin.sha256 -cne $row.before.sha256 -or $copyPin.bytes -ne $row.before.bytes){throw 'Exact SDK payload backup failed'}
        }
        AssertNoReparse87 $plan.localVulkan.path;Verify @($plan.localVulkan)
        [IO.File]::Copy($plan.localVulkan.path,"$out/before/consumer-Atom_RHI_Vulkan.Private.dll",$false)
        $localBackup=Pin "$out/before/consumer-Atom_RHI_Vulkan.Private.dll"
        if($localBackup.bytes -ne $plan.localVulkan.bytes -or $localBackup.sha256 -cne $plan.localVulkan.sha256){throw 'Exact local Vulkan backup failed'}
        $priorCl=$env:_CL_
        try{$env:_CL_=(([string]$env:_CL_)+' /MP1').Trim();Run 'build-vulkan' $recipe.cmake $plan.buildArgv $plan.repo}finally{$env:_CL_=$priorCl}
        VerifyEngine87;VerifyProtected;Verify $recipe.sourcePins;Verify $plan.consumerPins;VerifySnapshot|Out-Null
        if(Test-Path -LiteralPath $plan.rhiXml){[IO.File]::Copy($plan.rhiXml,"$out/before-rhi.xml",$false)}
        $testFailure=$null
        try{Run 'rhi-tests' $plan.ctest $plan.ctestArgv $plan.repo}catch{$testFailure=$_}
        if(!(Test-Path -LiteralPath $plan.rhiXml)){throw 'RHI fresh XML absent'}
        $testStart=Json "$out/rhi-tests.start.json"
        if((Get-Item -LiteralPath $plan.rhiXml).LastWriteTimeUtc -lt [DateTime]$testStart.creationUtc){throw 'RHI XML is stale'}
        [IO.File]::Copy($plan.rhiXml,"$out/rhi-tests.xml",$false)
        $xml=[xml][IO.File]::ReadAllText("$out/rhi-tests.xml");$cases=@($xml.SelectNodes('//testcase'))
        $active=@($cases|Where-Object{$_.status -ceq 'run' -and $_.result -ceq 'completed'})
        $disabled=@($cases|Where-Object{$_.status -ceq 'notrun' -and $_.result -ceq 'suppressed'}|ForEach-Object{"$($_.classname).$($_.name)"}|Sort-Object)
        $bad=@($cases|Where-Object{$_.SelectNodes('failure|error').Count})
        Save 'rhi-tests-review.json' @{xml=(Pin "$out/rhi-tests.xml");declared=$cases.Count;runCompleted=$active.Count;suppressed=$disabled;failureOrErrorCases=$bad.Count;rootTests=$xml.testsuites.tests;rootFailures=$xml.testsuites.failures;rootErrors=$xml.testsuites.errors;rootDisabled=$xml.testsuites.disabled;scope='Existing Stub/Null suite; not a Vulkan runtime substitute';nativeFailure=[string]$testFailure}
        if($testFailure){throw $testFailure}
        if($cases.Count -ne 281 -or $active.Count -ne 275 -or $disabled.Count -ne 6 -or ($disabled -join '|') -cne ($plan.rhiDisabledIdentities -join '|') -or $bad.Count -or [int]$xml.testsuites.tests -ne 281 -or [int]$xml.testsuites.failures -ne 0 -or [int]$xml.testsuites.errors -ne 0 -or [int]$xml.testsuites.disabled -ne 6){throw 'RHI requires275 active completed/0bad and exactly6 inherited suppressed identities'}
        Run 'install' $recipe.cmake $plan.installArgv $plan.repo
        $after=@(Inventory $recipe.sdkPrefix);Save 'sdk-inventory87.json' $after
        if($after.Count -ne 11218){throw 'SDK membership changed'}
        $beforeMap=@{};foreach($p in $expectedInventory){$beforeMap[$p.relativePath]=$p}
        $changed=@(foreach($p in $after){$old=$beforeMap[$p.relativePath];if(!$old){throw 'New SDK member forbidden'};if($old.bytes -ne $p.bytes -or $old.sha256 -cne $p.sha256){$p}})
        if($changed.Count -ne 2){throw 'Exactly DLL and static library must change; parent review required for anything else'}
        foreach($p in $changed){
            $row=@($plan.sdkPayloads|Where-Object relativePath -ceq $p.relativePath)
            if($row.Count -ne 1){throw 'Unapproved SDK payload changed'}
            $origin=Pin $row[0].origin
            if($origin.bytes -ne $p.bytes -or $origin.sha256 -cne $p.sha256){throw 'Installed Vulkan payload differs from actual producer'}
        }
        Verify $plan.sdkMetadataPins
        Save 'sdk-delta87.json' @{changed=$changed;added=@();removed=@();unchanged=11216;apiReview='PENDING_PARENT_EXPORTS_IMPORTS_REVIEW';originalInstallArgv=$plan.installArgv}
        $expectedInventory=$after;$stageComplete=$true
        Save 'stage-receipt.json' @{buildInstallComplete=$true;freezeSHA256=$FreezeSHA256;sdkInventory=(Pin "$out/sdk-inventory87.json");delta=(Pin "$out/sdk-delta87.json");localBackup=$localBackup;rhiReview=(Pin "$out/rhi-tests-review.json");nativeResults=@((Pin "$out/build-vulkan.result.json"),(Pin "$out/rhi-tests.result.json"),(Pin "$out/install.result.json"));runtimeExecuted=$false;parentApiReviewRequired=$true}
    }else{
        $local=$plan.localVulkan.path;AssertNoReparse87 $local;Verify @($plan.localVulkan)
        Verify @($stageReceipt.localBackup)
        $dll=Join-Path $recipe.sdkPrefix $plan.sdkPayloads[0].relativePath
        [IO.File]::Copy($dll,$local,$true)
        $sdkPin=Pin $dll;$localPin=Pin $local
        if($sdkPin.bytes -ne $localPin.bytes -or $sdkPin.sha256 -cne $localPin.sha256){throw 'Local Vulkan DLL update is not byteexact SDK87'}
        Save 'local-vulkan-update.json' @{before=$plan.localVulkan;backup=$stageReceipt.localBackup;after=$localPin;sdk=$sdkPin;exeAndPdbUnchanged=$plan.consumerPins;scope='One DLL only; observed CDB1 loaded SDK absolute DLL, not a proven old-local cause'}
        $snapshot=VerifySnapshot
        $text=[IO.File]::ReadAllText($run4)
        $first=$text.IndexOf('    $exe=$recipe.consumerExecutable',[StringComparison]::Ordinal)
        $last=$text.IndexOf('} catch {$fatal=$_.Exception.Message;throw} finally {',[StringComparison]::Ordinal)
        if($first -lt 0 -or $last -le $first){throw 'Unchanged Run4 runtime oracle block not found'}
        . ([scriptblock]::Create($text.Substring($first,$last-$first)))
        $stageComplete=$true
    }
}catch{$failure=$_.Exception.Message;throw}finally{
    try{Verify $plan.fixedPins;VerifyEngine87;Verify $recipe.sourcePins;Verify $plan.consumerPins;VerifyProtected;VerifySnapshot|Out-Null;VerifyInventory87 $expectedInventory;Assert-NoNative;if($Stage -ceq 'Runtime' -and $stageComplete){$sdkDll=Pin (Join-Path $recipe.sdkPrefix $plan.sdkPayloads[0].relativePath);$copyDll=Pin $plan.localVulkan.path;if($sdkDll.bytes -ne $copyDll.bytes -or $sdkDll.sha256 -cne $copyDll.sha256){throw 'Postflight local Vulkan DLL drift'}}}catch{$postFailure=$_.Exception.Message}
    $remaining=@(foreach($p in $script:cleanupResults){$live=Get-CimInstance Win32_Process -Filter "ProcessId=$($p.pid)";if($live -and $live.ExecutablePath -and [IO.Path]::GetFullPath($live.ExecutablePath) -ieq [IO.Path]::GetFullPath($p.exe) -and [Math]::Abs((([DateTime]$live.CreationDate).ToUniversalTime()-[DateTime]$p.creationUtc).TotalMilliseconds) -lt 1){$p}})
    Save 'postflight.json' @{stage=$Stage;stageComplete=$stageComplete;failure=$failure;postflightFailure=$postFailure;allPostflightChecksPassed=($null -eq $postFailure);sourceCount=14034;sdkCount=11218;protected=40;owner=26;snapshot=15;remainingObservedIdentities=$remaining;helpersObservedAlive=$remaining.Count;acceptance='Parent only; no visual/VR/Linux/Shipping/globalAP/Gem acceptance'}
    if($postFailure){throw "Postflight failed: $postFailure"}
}
