param([switch]$Execute,[string]$RecipePath,[string]$RecipeSHA256,[string]$SnapshotPath,[string]$SnapshotReceiptSHA256,[string]$FreezePath,[string]$FreezeSHA256)
$ErrorActionPreference='Stop'
if(!$Execute){Write-Output 'PREPARED_NOT_RUN: no configure/build/consumer/AP/GUI or snapshot execution.';return}
foreach($hash in @($RecipeSHA256,$SnapshotReceiptSHA256,$FreezeSHA256)){if($hash -cnotmatch '^[0-9A-F]{64}$'){throw 'Explicit real recipe/snapshot/freeze SHA256 values required'}}
$repo='F:/JericoEngine/JericoEngine'
$pbr="$repo/build/n0-validation/native-render-builders-integration-rev1/material-pbr-preview-integration-rev1"
$base="$pbr/atomshader-native83-sdk-preparation-rev1/ResumeSdkConsumer83AfterBuild.ps1"
if((Get-FileHash -LiteralPath $base).Hash -cne '00E1342C2B052F347316498326F9A806EC85EC5E365E879B54E065FF608F7D4B'){throw 'Exact reviewed SDK83 native-run functions changed'}
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($base,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw 'SDK83 parser failure'}
foreach($name in @('Json','Save','Pin','Verify','NativeAdmission','Resources','Run','Inventory')){
    $defs=@($ast.FindAll({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst]},$false)|Where-Object Name -ceq $name)
    if($defs.Count -ne 1){throw "Missing/ambiguous SDK83 function $name"}
    $code=$defs[0].Extent.Text
    if($name -ceq 'Run'){
        # Preserve SDK83 admission/80% guard/exit handling; add only owned-child identity accounting.
        foreach($pair in @(
            @('try { $process.PriorityClass = [Diagnostics.ProcessPriorityClass]::BelowNormal } catch { $priorityError = $_.Exception.Message }','try { $process.PriorityClass = [Diagnostics.ProcessPriorityClass]::BelowNormal } catch { $priorityError = $_.Exception.Message }; Record-PhaseTree $phase $ownedPid $creation $exe'),
            @('$timedOut = $clock.ElapsedMilliseconds','Record-PhaseTree $phase $ownedPid $creation $exe; $timedOut = $clock.ElapsedMilliseconds'),
            @('$process.Dispose()','Record-PhaseTree $phase $ownedPid $creation $exe; Close-PhaseOwned $phase; $process.Dispose()')
        )){if(([regex]::Matches($code,[regex]::Escape($pair[0]))).Count -ne 1){throw 'Native-run instrumentation anchor changed'};$code=$code.Replace($pair[0],$pair[1])}
    }
    . ([scriptblock]::Create($code))
}
$script:owned=@{}
$script:cleanupResults=@()
function Record-PhaseTree($phase,$rootId,$rootCreation,$rootExe){
    if(!$script:owned.ContainsKey($phase)){$script:owned[$phase]=@{};$script:owned[$phase][$rootId]=[pscustomobject]@{pid=$rootId;creationUtc=$rootCreation;exe=$rootExe;parent=0}}
    $all=@(Get-CimInstance Win32_Process);$census=@{};foreach($p in $all){$census[[int]$p.ProcessId]=$p};$changed=$true
    while($changed){$changed=$false;foreach($p in $all){
        $parent=$script:owned[$phase][[int]$p.ParentProcessId];$liveParent=$census[[int]$p.ParentProcessId]
        if($parent -and $liveParent -and $liveParent.ExecutablePath -and !$script:owned[$phase].ContainsKey([int]$p.ProcessId) -and $p.ExecutablePath){
            $sameParent=[IO.Path]::GetFullPath($liveParent.ExecutablePath) -ieq [IO.Path]::GetFullPath($parent.exe) -and [Math]::Abs((([DateTime]$liveParent.CreationDate).ToUniversalTime()-[DateTime]$parent.creationUtc).TotalMilliseconds) -lt 1
            $created=([DateTime]$p.CreationDate).ToUniversalTime()
            if($sameParent -and $created -ge [DateTime]$parent.creationUtc){$script:owned[$phase][[int]$p.ProcessId]=[pscustomobject]@{pid=[int]$p.ProcessId;creationUtc=$created;exe=$p.ExecutablePath;parent=[int]$p.ParentProcessId};$changed=$true}
        }
    }}
}
function Close-PhaseOwned($phase){
    $records=@($script:owned[$phase].Values);$cleanup=@(foreach($p in ($records|Sort-Object creationUtc -Descending)){
        $now=Get-CimInstance Win32_Process -Filter "ProcessId=$($p.pid)"
        $action='already-absent';$absent=!$now
        if($now){
            if(!$now.ExecutablePath -or [IO.Path]::GetFullPath($now.ExecutablePath) -ine [IO.Path]::GetFullPath($p.exe) -or [Math]::Abs((([DateTime]$now.CreationDate).ToUniversalTime()-[DateTime]$p.creationUtc).TotalMilliseconds) -ge 1){$action='identity-unconfirmed-preserved'}
            elseif([IO.Path]::GetFileName($p.exe) -ieq 'mspdbsrv.exe'){$action='potentially-shared-pdb-server-preserved'}
            elseif(@(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($p.pid)").Count){$action='live-descendants-preserved-no-tree-kill'}
            else{
                $live=[Diagnostics.Process]::GetProcessById($p.pid)
                try{
                    if(!$live.HasExited){
                        if([Math]::Abs(($live.StartTime.ToUniversalTime()-[DateTime]$p.creationUtc).TotalMilliseconds) -ge 1 -or [IO.Path]::GetFullPath($live.MainModule.FileName) -ine [IO.Path]::GetFullPath($p.exe)){$action='process-handle-identity-unconfirmed-preserved'}
                        else{$live.Kill();if(!$live.WaitForExit(5000)){throw 'Owned child did not close'};$action='individual-owned-stop'}
                    }
                }finally{$live.Dispose()}
                $absent=!(Get-CimInstance Win32_Process -Filter "ProcessId=$($p.pid)")
            }
        }
        [ordered]@{pid=$p.pid;creationUtc=$p.creationUtc;exe=$p.exe;action=$action;absent=$absent}
    })
    $script:cleanupResults+=@($cleanup)
    Save "$phase.identities-cleanup.json" @{identities=$records;cleanup=$cleanup;unconfirmedDescendants='Children missed after their parent exited cannot be assigned ownership; global native census still required';ownership='Observed parent PID+exe+creation identity before accepting children; individual verified stops only; PDB servers preserved'}
}
function Assert-NoNative {
    Resources
    if(@(Get-CimInstance Win32_Process|Where-Object Name -match '^(JENativeShaderRuntimeConsumer|.+\.GameLauncher)\.exe$').Count){throw 'A runtime consumer or GameLauncher is already active'}
}
function VerifyEngine {
    Verify @($recipe.parentFreezeReview)
    $review=Json $recipe.parentFreezeReview.path
    if($review.owner -cne 'root' -or !$review.approvedEngineFreeze -or $review.inputCount -ne 14034 -or $review.freezeSHA256 -cne $FreezeSHA256 -or [IO.Path]::GetFullPath($review.freezePath) -ine [IO.Path]::GetFullPath($FreezePath)){throw 'Actual parent engine86 freeze review required'}
    Verify @(@{path=$FreezePath;bytes=$script:freezeBytes;sha256=$FreezeSHA256})
    $f=Json $FreezePath
    if(@($f.inputs).Count -ne 14034){throw 'Actual engine86 complete14034 input cohort required'}
    $unique=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach($p in $f.inputs){if(!$p.path -or !$unique.Add([IO.Path]::GetFullPath($p.path))){throw 'Duplicate/empty engine input'}}
    Verify $f.inputs
}
function VerifySdk {
    Verify @($recipe.sdkInventory,$recipe.parentSdkReview)
    $expected=@(Json $recipe.sdkInventory.path);$actual=@(Inventory $recipe.sdkPrefix)
    if($expected.Count -ne 11218 -or $actual.Count -ne $expected.Count){throw 'SDK83 inventory changed'}
    $map=@{};foreach($p in $expected){if($map.ContainsKey($p.relativePath)){throw 'Duplicate SDK inventory entry'};$map[$p.relativePath]=$p}
    foreach($p in $actual){$prior=$map[$p.relativePath];if(!$prior -or $prior.bytes -ne $p.bytes -or $prior.sha256 -cne $p.sha256){throw "SDK drift: $($p.relativePath)"}}
}
function VerifySnapshot {
    Verify @(@{path="$SnapshotPath/snapshot-receipt.json";bytes=$script:snapshotReceiptBytes;sha256=$SnapshotReceiptSHA256})
    $s=Json "$SnapshotPath/snapshot-receipt.json"
    if($s.state -cne 'SNAPSHOT_COMPLETE_NOT_RUNTIME_ACCEPTANCE' -or $s.payloads -ne 15 -or $s.runtimeAssets -ne 6 -or $s.catalog.sha256 -cne '745CB10B631D8B7464102C989D826CC8A9ECF4D48315C41B13021FB523DBFB46' -or $s.productsEvidence.sha256 -cne '03C190D2DC405879FDF23D2CB5CB1BA638CBB935B3C41288C53168B3FF0E3C3F'){throw 'Unexpected snapshot provenance'}
    $root=[IO.Path]::GetFullPath($SnapshotPath).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    foreach($p in @($s.catalog,$s.manifest)+@($s.products)){
        if(![IO.Path]::GetFullPath($p.path).StartsWith($root,[StringComparison]::OrdinalIgnoreCase)){throw 'Snapshot pin escapes its private root'}
        $item=Get-Item -LiteralPath $p.path
        while($item){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Snapshot reparse point forbidden'};$item=if($item -is [IO.FileInfo]){$item.Directory}else{$item.Parent}}
    }
    Verify @($s.catalog,$s.manifest,$s.catalogSource,$s.productsEvidence,$s.queryEvidence,$s.negativeSelection);Verify $s.products;Verify $s.physicalOriginals;Verify $s.archiveOriginals
    $manifest=Json $s.manifest.path
    if($manifest.schema -cne 'je-shader-runtime86-v1' -or @($manifest.assets).Count -ne 6){throw 'Runtime manifest contract changed'}
    return $s
}
function VerifyProtected {
    Verify @($recipe.protected,$recipe.owner)
    $authored=Json $recipe.protected.path;$owner=Json $recipe.owner.path
    if(@($authored.inputs).Count -ne 40 -or @($owner.inputs).Count -ne 26){throw 'Protected40/owner26 counts required'}
    Verify $authored.inputs;Verify $owner.inputs
}
function Review-LoadedModules($result,$nativeStart,$executablePin){
    $capture=$result.moduleSnapshot
    if(!$capture.complete -or $capture.win32Error -ne 0 -or $capture.processId -ne $nativeStart.pid -or $capture.phase -cne 'post-probe-before-runtime-shutdown' -or @($capture.paths).Count -lt 1){throw 'Complete process-local native module snapshot required'}
    $sdkBin=[IO.Path]::GetFullPath($recipe.sdkBin).TrimEnd('\','/')
    $consumerBin=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($recipe.consumerExecutable))
    $inventory=@(Json $recipe.sdkInventory.path);$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $required=@('Atom_RHI.Private.dll','Atom_RHI_Vulkan.Private.dll','Atom_RPI.Public.dll','AzCore.dll','AzFramework.dll')
    $observed=@(foreach($path in $capture.paths){
        if(![IO.Path]::IsPathFullyQualified($path)){throw 'Native module path is not absolute'}
        $full=[IO.Path]::GetFullPath($path);$name=[IO.Path]::GetFileName($full)
        if(!$seen.Add($full)){throw 'Duplicate native module path'}
        if($name -match 'Atom_RHI_(DX12|Metal|Null)|Python|Editor|Qt[56]|AzToolsFramework|RenderAssetBuilders'){throw "Forbidden module observed in this runtime capture: $name"}
        $directory=[IO.Path]::GetDirectoryName($full);$pin=$null;$sdkOrigin=$null;$scope='external-recorded-only'
        if($full -ieq [IO.Path]::GetFullPath($executablePin.path)){$pin=Pin $full;if($pin.bytes -ne $executablePin.bytes -or $pin.sha256 -cne $executablePin.sha256){throw 'Loaded consumer executable changed'};$scope='consumer-executable'}
        elseif($directory -ieq $sdkBin -or $directory -ieq $consumerBin){
            $relative='bin/Windows/profile/Default/'+$name
            $expected=@($inventory|Where-Object relativePath -ieq $relative)
            if($expected.Count -ne 1){throw "Loaded SDK/consumer module has no unique accepted SDK83 Profile pin: $name"}
            $pin=Pin $full
            if($pin.bytes -ne $expected[0].bytes -or $pin.sha256 -cne $expected[0].sha256){throw "Loaded module differs from accepted SDK83: $name"}
            $sdkOrigin=$relative;$scope=if($directory -ieq $sdkBin){'installed-sdk-profile'}else{'consumer-copy-byteexact-sdk-profile'}
        }elseif($required -icontains $name){throw "Required native module loaded outside SDK/consumer Profile roots: $full"}
        [ordered]@{name=$name;path=$full;scope=$scope;pin=$pin;sdkOrigin=$sdkOrigin}
    })
    foreach($name in $required){if(@($observed|Where-Object name -ieq $name).Count -ne 1){throw "Required runtime module absent/duplicate in this capture: $name"}}
    return @{phase=$capture.phase;processId=$capture.processId;modules=$observed;limit='One native capture while Runtime is alive; no absence claim over the entire process lifetime'}
}
function Verify-ExistingConfiguredBuild {
    $expected=@("$PSScriptRoot/recipe-attempt3.json","$PSScriptRoot/execution-runtime86-attempt3/configure.start.json","$PSScriptRoot/execution-runtime86-attempt3/configure.result.json","$PSScriptRoot/execution-runtime86-attempt3/postflight.json","$PSScriptRoot/parent-native86-attempt3-terminal.json","$shortBuild/CMakeCache.txt")
    if(@($recipe.existingBuildPins).Count -ne $expected.Count){throw 'Exact prior configure/build provenance pins required'}
    foreach($path in $expected){if(@($recipe.existingBuildPins|Where-Object{[IO.Path]::GetFullPath($_.path) -ieq [IO.Path]::GetFullPath($path)}).Count -ne 1){throw 'Missing/duplicate existing build provenance path'}}
    Verify $recipe.existingBuildPins
    $previous=Json $expected[0];$start=Json $expected[1];$result=Json $expected[2];$post=Json $expected[3];$terminal=Json $expected[4]
    if([IO.Path]::GetFullPath($recipe.consumerBuild) -ine $shortBuild -or [IO.Path]::GetFullPath($previous.consumerBuild) -ine $shortBuild -or [IO.Path]::GetFullPath($previous.sourceRoot) -ine [IO.Path]::GetFullPath($recipe.sourceRoot) -or ($start.argv -join '|') -cne ($previous.configureArgv -join '|') -or ($start.argv -join '|') -cne ($recipe.configureArgv -join '|') -or [IO.Path]::GetFullPath($start.cwd) -ine [IO.Path]::GetFullPath($recipe.sourceRoot) -or [IO.Path]::GetFullPath($start.executable) -ine [IO.Path]::GetFullPath($recipe.cmake) -or $start.pid -le 0 -or !$start.creationUtc){throw 'Existing short build is not the exact prior configured consumer'}
    Verify @($result.stdout,$result.stderr)
    if($result.exitCode -ne 0 -or $result.ramGuardTriggered -or $result.timedOut -or $result.priorityError -or $result.priorityRequested -cne 'BelowNormal' -or !$post.allPostflightChecksPassed -or $terminal.parent -cne 'root' -or $terminal.attempt -ne 3 -or $terminal.configureExit -ne 0 -or $terminal.remainingNativeJobs -ne 0){throw 'Prior configure0 and closed native3 provenance required; failed build is preserved'}
    $cache=Get-Item -LiteralPath $expected[5]
    if($cache.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Existing CMake cache reparse point forbidden'}
    $values=@{};foreach($line in [IO.File]::ReadAllLines($cache.FullName)){if($line -match '^(CMAKE_HOME_DIRECTORY|CMAKE_CACHEFILE_DIR|JE_SDK_PREFIX|CMAKE_PROJECT_NAME|CMAKE_GENERATOR):[^=]+=(.*)$'){if($values.ContainsKey($Matches[1])){throw 'Duplicate cache identity key'};$values[$Matches[1]]=$Matches[2]}}
    if([IO.Path]::GetFullPath($values.CMAKE_HOME_DIRECTORY) -ine [IO.Path]::GetFullPath($recipe.sourceRoot) -or [IO.Path]::GetFullPath($values.CMAKE_CACHEFILE_DIR) -ine $shortBuild -or [IO.Path]::GetFullPath($values.JE_SDK_PREFIX) -ine [IO.Path]::GetFullPath($recipe.sdkPrefix) -or $values.CMAKE_PROJECT_NAME -cne $recipe.target -or $values.CMAKE_GENERATOR -cne $recipe.configureArgv[5]){throw 'Existing cache source/build/SDK/generator identity differs'}
}
if((Get-FileHash -LiteralPath $RecipePath).Hash -cne $RecipeSHA256){throw 'Recipe changed'}
$recipe=Json $RecipePath
if($recipe.state -cne 'READY_PARENT_REVIEW_REQUIRED' -or $recipe.target -cne 'JENativeShaderRuntimeConsumer' -or $recipe.sdkPrefix -cne "$repo/build/sdk-vk77" -or @($recipe.sourcePins).Count -ne 4){throw 'Final real four-source/recipe pins are not ready'}
$out=$recipe.evidenceDirectory
$shortBuild=[IO.Path]::GetFullPath("$repo/build/sdk-vk-consumer86")
foreach($path in @($out,$recipe.consumerBuild)){
    $full=[IO.Path]::GetFullPath($path);$root=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    $allowedShortBuild=[IO.Path]::IsPathFullyQualified($path) -and $full -ieq $shortBuild -and $full -ieq [IO.Path]::GetFullPath($recipe.consumerBuild) -and $full -ine [IO.Path]::GetFullPath($out)
    $existingShortBuild=$allowedShortBuild -and (Test-Path -LiteralPath $full -PathType Container)
    if($allowedShortBuild -and !$existingShortBuild){throw 'Exact previously configured short build must exist; no clone/delete/new build'}
    if((!$full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -and !$allowedShortBuild) -or $full -ieq ($root+'source') -or $full.StartsWith($root+'source'+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or ((Test-Path -LiteralPath $full) -and !$existingShortBuild)){throw 'New private evidence and exact proven existing short build required; no overwrite'}
    if($allowedShortBuild){
        $parent=Get-Item -LiteralPath $full
        while($parent){if($parent.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Short build parent reparse point forbidden'};$parent=$parent.Parent}
    }
}
if([IO.Path]::GetFullPath($out) -ieq [IO.Path]::GetFullPath($recipe.consumerBuild)){throw 'Execution and consumer build directories must differ'}
Verify @($recipe.baseRecipe)
$prior=Json $recipe.baseRecipe.path
$expectedConfigure=@($prior.configureArgv);$expectedConfigure[1]=$recipe.sourceRoot;$expectedConfigure[3]=$recipe.consumerBuild
$expectedBuild=@($prior.buildArgv);$expectedBuild[1]=$recipe.consumerBuild;$expectedBuild[5]=$recipe.target
if(@($recipe.configureArgv).Count -ne 43 -or ($recipe.configureArgv -join '|') -cne ($expectedConfigure -join '|') -or ($recipe.buildArgv -join '|') -cne ($expectedBuild -join '|') -or $recipe.cmake -cne $prior.executable){throw 'Exact inherited offline43 configure/serial build arguments required; only source/build/target paths change'}
if($FreezeSHA256 -cne '63F49B1B97E1F5A4CD0764AC27925C9D1063CB0095F22F98A4B210AB5C8CA606'){throw 'Actual reviewed engine86 freeze required, not old82'}
$script:freezeBytes=(Get-Item -LiteralPath $FreezePath).Length
$script:snapshotReceiptBytes=(Get-Item -LiteralPath "$SnapshotPath/snapshot-receipt.json").Length
Assert-NoNative;NativeAdmission
Verify $recipe.sourcePins;Verify $recipe.preparationPins;VerifyEngine;VerifyProtected;VerifySdk
$snapshot=VerifySnapshot
Verify-ExistingConfiguredBuild
New-Item -ItemType Directory -Path $out -ErrorAction Stop|Out-Null
Save 'preflight.json' @{freeze=(Pin $FreezePath);snapshot=(Pin "$SnapshotPath/snapshot-receipt.json");recipe=(Pin $RecipePath);nativeLaunches=0;sourceCount=14034;sdkCount=11218;protected=40;owner=26}
$fatal=$null
try {
    Run 'configure' $recipe.cmake $recipe.configureArgv $recipe.sourceRoot
    Run 'build-consumer' $recipe.cmake $recipe.buildArgv $recipe.sourceRoot
    Verify $recipe.sourcePins;Verify $recipe.preparationPins;$snapshot=VerifySnapshot
    $exe=$recipe.consumerExecutable
    $executablePin=Pin $exe
    $productsRoot="$SnapshotPath/products/pc"
    $args=@('--sdk-bin',$recipe.sdkBin,'--products-root',$productsRoot,'--catalog',$snapshot.catalog.path,'--manifest',$snapshot.manifest.path)
    foreach($mode in @('positive','negative-missing')){
        Assert-NoNative
        $userRoot="$out/user-$mode"
        New-Item -ItemType Directory -Path $userRoot -ErrorAction Stop|Out-Null
        $caught=$null
        try{Run $mode $exe (@('--mode',$mode)+$args+@('--user-root',$userRoot)) $productsRoot $recipe.consumerPath 180000}catch{$caught=$_}
        $native=Json "$out/$mode.result.json"
        $expectedCode=if($mode -ceq 'positive'){0}else{20}
        if($native.exitCode -ne $expectedCode -or $native.ramGuardTriggered -or $native.timedOut -or $native.priorityError){if($caught){throw $caught};throw 'Native runtime phase failed'}
        $lines=@([IO.File]::ReadAllLines("$out/$mode.stdout.log")|Where-Object{$_.StartsWith('JE_SHADER_RUNTIME86_RESULT=',[StringComparison]::Ordinal)})
        if($lines.Count -ne 1){throw 'Exactly one native result JSON marker required'}
        $r=$lines[0].Substring('JE_SHADER_RUNTIME86_RESULT='.Length)|ConvertFrom-Json
        if($r.schema -cne 'je-shader-runtime86-result-v2' -or $r.mode -cne $mode -or $r.exitCode -ne $expectedCode -or !$r.cleanupComplete -or !$r.noWindowOrDraw -or $r.jobWorkerThreads -ne 1){throw 'Native result/cleanup/actual JobManager worker contract failed'}
        $moduleReview=Review-LoadedModules $r (Json "$out/$mode.start.json") $executablePin
        Save "$mode.module-review.json" $moduleReview
        if($mode -ceq 'negative-missing'){
            if($r.ok -or !$r.expectedNegative -or $r.stage -cne 'negative-catalog-lookup'){throw 'Missing asset was not rejected as specified'}
        }else{
            $backendCrc=$r.backend.typeCrc32
            if(($backendCrc -isnot [int] -and $backendCrc -isnot [long]) -or $backendCrc -ne 3189070339 -or !$r.ok -or $r.expectedNegative -or !$r.shaderInstanceCreated -or @($r.assets).Count -ne 6 -or !$r.backend.deviceName -or $r.backend.deviceCount -ne 1 -or $r.backend.apiIndex -ne 2){throw 'Real Vulkan CRC32/Ready object contract failed'}
            $manifest=Json $snapshot.manifest.path
            foreach($asset in $manifest.assets){
                $loaded=@($r.assets|Where-Object role -ceq $asset.role)
                if($loaded.Count -ne 1){throw 'Missing/duplicate native role'}
                $row=$loaded[0]
                if(!$row.ready -or $row.status -cne 'Ready' -or $row.guid -ine $asset.guid -or $row.subId -ne $asset.subId -or $row.type -ine $asset.type -or $row.productPath -cne $asset.productPath -or $row.loadedGuid -ine $asset.guid -or $row.loadedSubId -ne $asset.subId -or $row.loadedType -ine $asset.type){throw 'Actual catalog/loaded Asset identity/Ready/type/path mismatch'}
                if($asset.PSObject.Properties.Name -contains 'stableId'){if($row.stableId -ne $asset.stableId){throw 'Loaded stable ID differs'}}
                if($asset.role -ceq 'root' -or $asset.role.StartsWith('variant',[StringComparison]::Ordinal)){if($null -eq $row.stages -or @($row.stages).Count -lt 1){throw 'Loaded Vulkan variant has no stage payload'}}
                if($asset.role -ceq 'tree' -and $row.nodeCount -lt 1){throw 'Loaded variant tree is empty'}
                if($asset.role -ceq 'shader' -and (($row.apiSelectedCrc32 -isnot [int] -and $row.apiSelectedCrc32 -isnot [long]) -or $row.apiSelectedCrc32 -ne $backendCrc -or $row.selectedRootApiIndex -ne 2 -or $row.selectedRootId -cne @($r.assets|Where-Object role -ceq 'root')[0].id -or $r.shaderInstanceAssetId -cne $row.id)){throw 'Shader instance/selected Vulkan root/API CRC32 differs from loaded assets'}
                foreach($stage in $row.stages){if($stage.typeId -ine '{A606478A-97E9-402D-A776-88EE72DAC6F9}' -or $stage.backend -cne 'vulkan' -or $stage.spirvMagic -ne 119734787 -or $stage.bytes -lt 20 -or $stage.bytes%4 -ne 0){throw 'Actual Vulkan stage RTTI/SPIRV payload failed'}}
                $expectedDeps=@($manifest.metadataDependencies|Where-Object{$_.ownerGuid -ieq $asset.guid -and $_.ownerSubId -eq $asset.subId})
                $actualDeps=@($row.directDependencies)
                if($actualDeps.Count -ne $expectedDeps.Count){throw 'Native catalog dependency count differs from AP85 metadata'}
                foreach($dep in $actualDeps){
                    $copied=@($snapshot.products|Where-Object{$_.guid -ieq $dep.guid -and $_.subId -eq $dep.subId -and $_.type -ieq $dep.type -and $_.productName -ceq ('pc/'+$dep.productPath)})
                    if($copied.Count -ne 1){throw 'Native dependency is not closed by exact copied product identity/type/path'}
                    $edge=@($expectedDeps|Where-Object{$_.guid -ieq $dep.guid -and $_.subId -eq $dep.subId -and $_.type -ieq $dep.type -and $_.productPath -ceq $dep.productPath -and $_.flags -eq $dep.flags})
                    if($edge.Count -ne 1){throw 'Native catalog dependency/PreLoad flags differ from exact AP85 edge'}
                }
            }
        }
        Save "$mode.review.json" @{nativeResult=$r;rawExit=$native.exitCode;expectedNegative=($mode -ceq 'negative-missing');parentAcceptanceRequired=$true}
        Verify @($executablePin);VerifySnapshot|Out-Null
    }
} catch {$fatal=$_.Exception.Message;throw} finally {
    $postflightFailure=$null
    try{Verify $recipe.sourcePins;Verify $recipe.preparationPins;VerifyEngine;VerifyProtected;VerifySdk;VerifySnapshot|Out-Null;Assert-NoNative}catch{$postflightFailure=$_.Exception.Message}
    $remaining=@(foreach($p in $script:cleanupResults){$now=Get-CimInstance Win32_Process -Filter "ProcessId=$($p.pid)";if($now -and $now.ExecutablePath -and [IO.Path]::GetFullPath($now.ExecutablePath) -ieq [IO.Path]::GetFullPath($p.exe) -and [Math]::Abs((([DateTime]$now.CreationDate).ToUniversalTime()-[DateTime]$p.creationUtc).TotalMilliseconds) -lt 1){$p}})
    Save 'postflight.json' @{failure=$fatal;postflightFailure=$postflightFailure;allPostflightChecksPassed=($null -eq $postflightFailure);sourceCount=14034;SDKExpectedCount=11218;protectedExpectedCount=40;ownerExpectedCount=26;catalogAndProductsExpectedCount=15;remainingObservedIdentities=$remaining;helpersObservedAlive=$remaining.Count;acceptance='Parent only; no draw/visual/VR/Linux/Shipping/globalAP/Gem acceptance'}
    if($postflightFailure){throw "Postflight failed: $postflightFailure"}
}
