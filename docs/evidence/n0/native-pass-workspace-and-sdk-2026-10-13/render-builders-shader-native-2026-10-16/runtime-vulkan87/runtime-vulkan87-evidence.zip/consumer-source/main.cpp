// Private installed-SDK validation only: no scene, swapchain, SRG, PSO or draw.
#include <AzCore/Asset/AssetManager.h>
#include <AzCore/Asset/AssetManagerComponent.h>
#include <AzCore/Component/ComponentApplication.h>
#include <AzCore/Component/TickBus.h>
#include <AzCore/Console/IConsole.h>
#include <AzCore/Debug/TraceMessageBus.h>
#include <AzCore/IO/Streamer/StreamerComponent.h>
#include <AzCore/Jobs/JobManager.h>
#include <AzCore/Jobs/JobManagerBus.h>
#include <AzCore/Jobs/JobManagerComponent.h>
#include <AzCore/Module/ModuleManagerBus.h>
#include <AzCore/Name/Name.h>
#include <AzCore/Serialization/SerializeContext.h>
#include <AzCore/Settings/SettingsRegistry.h>
#include <AzCore/Settings/SettingsRegistryMergeUtils.h>
#include <AzCore/Task/TaskGraphSystemComponent.h>
#include <AzCore/JSON/document.h>
#include <AzCore/JSON/stringbuffer.h>
#include <AzCore/JSON/writer.h>
#include <AzFramework/Asset/AssetCatalog.h>
#include <AzFramework/Asset/AssetRegistry.h>
#include <AzFramework/IO/LocalFileIO.h>
#include <Atom/RHI/Factory.h>
#include <Atom/RHI/PhysicalDevice.h>
#include <Atom/RHI/RHISystem.h>
#include <Atom/RHI.Reflect/Vulkan/ShaderStageFunction.h>
#include <Atom/RPI.Public/AssetInitBus.h>
#include <Atom/RPI.Public/Shader/Shader.h>
#include <Atom/RPI.Public/Shader/ShaderSystem.h>
#include <Atom/RPI.Reflect/Shader/ShaderAsset.h>
#include <Atom/RPI.Reflect/Shader/ShaderVariantAsset.h>
#include <Atom/RPI.Reflect/Shader/ShaderVariantTreeAsset.h>
#include <array>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <stdexcept>
#if defined(_WIN32)
#include <Windows.h>
#include <TlHelp32.h>
#endif

namespace
{
    using Json = rapidjson::Value;
    using Allocator = rapidjson::Document::AllocatorType;
    namespace fs = std::filesystem;
    static_assert(AZ::RHI::APIType("vulkan").GetValue() == 0xBE155A03u);
    struct Options { std::string mode, sdk, products, catalog, manifest, user; };
    struct Expected
    {
        const char* role;
        const char* guid;
        AZ::u32 subId;
        AZ::u32 stableId;
    };
    constexpr std::array<Expected, 6> ExpectedAssets{{
        {"shader", "{B5C5AE95-EC8D-5786-9417-BC6C0A464B32}", 0, 0},
        {"root", "{B5C5AE95-EC8D-5786-9417-BC6C0A464B32}", 0x80000001u, 0},
        {"tree", "{5F0DD24D-BD82-5EB1-8DBC-5F3DED6CDAE4}", 0, 0},
        {"variant1", "{7391379C-F65F-5A5B-AFDD-BE2C66FE9BA6}", 0x80000001u, 1},
        {"variant2", "{7391379C-F65F-5A5B-AFDD-BE2C66FE9BA6}", 0x80000002u, 2},
        {"variant3", "{7391379C-F65F-5A5B-AFDD-BE2C66FE9BA6}", 0x80000003u, 3}
    }};

    void Text(Json& value, const char* key, const std::string& text, Allocator& a)
    {
        value.AddMember(rapidjson::StringRef(key), Json(text.c_str(), static_cast<rapidjson::SizeType>(text.size()), a), a);
    }
    void ReplaceText(Json& value, const char* key, const std::string& text, Allocator& a)
    {
        value[key].SetString(text.c_str(), static_cast<rapidjson::SizeType>(text.size()), a);
    }
    int Fail(rapidjson::Document& report, const char* stage, const std::string& reason, int code)
    {
        ReplaceText(report, "stage", stage, report.GetAllocator());
        ReplaceText(report, "error", reason, report.GetAllocator());
        return code;
    }
    std::string IdText(const AZ::Data::AssetId& id) { return id.ToString<AZStd::string>().c_str(); }
    std::string TypeText(const AZ::Uuid& type) { return type.ToString<AZStd::string>().c_str(); }
    bool ParseOptions(int argc, char** argv, Options& o)
    {
        if (argc != 13) { return false; }
        for (int i = 1; i < argc; i += 2)
        {
            std::string* target = nullptr;
            if (!std::strcmp(argv[i], "--mode")) target = &o.mode;
            else if (!std::strcmp(argv[i], "--sdk-bin")) target = &o.sdk;
            else if (!std::strcmp(argv[i], "--products-root")) target = &o.products;
            else if (!std::strcmp(argv[i], "--catalog")) target = &o.catalog;
            else if (!std::strcmp(argv[i], "--manifest")) target = &o.manifest;
            else if (!std::strcmp(argv[i], "--user-root")) target = &o.user;
            else return false;
            if (!target->empty()) return false;
            *target = argv[i + 1];
        }
        return (o.mode == "positive" || o.mode == "negative-missing") &&
            !o.sdk.empty() && !o.products.empty() && !o.catalog.empty() && !o.manifest.empty() && !o.user.empty();
    }
    bool CaptureModules(rapidjson::Document& report)
    {
        auto& a = report.GetAllocator();
        Json snapshot(rapidjson::kObjectType);
        Text(snapshot, "phase", "post-probe-before-runtime-shutdown", a);
        snapshot.AddMember("complete", false, a);
        Json paths(rapidjson::kArrayType);
        DWORD failure = ERROR_SUCCESS;
        const HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
        if (handle == INVALID_HANDLE_VALUE) failure = GetLastError();
        else
        {
            const std::unique_ptr<void, decltype(&CloseHandle)> ownedSnapshot(handle, &CloseHandle);
            MODULEENTRY32W entry{};
            entry.dwSize = sizeof(entry);
            if (!Module32FirstW(handle, &entry)) failure = GetLastError();
            else
            {
                do
                {
                    const int size = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, entry.szExePath, -1, nullptr, 0, nullptr, nullptr);
                    if (size <= 1) { failure = size ? ERROR_INVALID_DATA : GetLastError(); break; }
                    std::string path(static_cast<size_t>(size), '\0');
                    if (!WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, entry.szExePath, -1, path.data(), size, nullptr, nullptr))
                    { failure = GetLastError(); break; }
                    path.pop_back(); // Exclude the UTF-8 terminator from the JSON string.
                    paths.PushBack(Json(path.c_str(), static_cast<rapidjson::SizeType>(path.size()), a), a);
                } while (Module32NextW(handle, &entry));
                if (failure == ERROR_SUCCESS)
                {
                    const DWORD end = GetLastError();
                    if (end != ERROR_NO_MORE_FILES) failure = end == ERROR_SUCCESS ? ERROR_INVALID_DATA : end;
                }
            }
        }
        const bool complete = failure == ERROR_SUCCESS && !paths.Empty();
        snapshot["complete"].SetBool(complete);
        snapshot.AddMember("win32Error", static_cast<uint32_t>(failure), a);
        snapshot.AddMember("processId", static_cast<uint32_t>(GetCurrentProcessId()), a);
        snapshot.AddMember("paths", paths, a);
        report.AddMember("moduleSnapshot", snapshot, a);
        return complete;
    }
    struct TraceObserver final : AZ::Debug::TraceMessageBus::Handler
    {
        std::atomic<unsigned> assertions{0}, errors{0}, exceptions{0};
        TraceObserver() { BusConnect(); }
        ~TraceObserver() { BusDisconnect(); }
        bool OnPreAssert(const char* file, int line, const char* function, const char* message) override
        {
            ++assertions;
            std::fprintf(stderr, "RUNTIME86 ASSERT %s:%d %s: %s\n", file, line, function, message);
            return true; // Avoid an interactive assert; every recorded assertion fails this probe.
        }
        bool OnPreError(const char* window, const char* file, int line, const char* function, const char* message) override
        {
            ++errors;
            std::fprintf(stderr, "RUNTIME86 ERROR [%s] %s:%d %s: %s\n", window, file, line, function, message);
            return true; // Preserve diagnostic text/counter, never treat the absorbed error as success.
        }
        bool OnException(const char* message) override
        {
            ++exceptions;
            std::fprintf(stderr, "RUNTIME86 OS EXCEPTION: %s\n", message);
            return false; // Never continue execution after an OS exception.
        }
    };
    struct Runtime
    {
        AZ::ComponentApplication application;
        AZ::Entity* entity = nullptr;
        AZ::IO::FileIOBase* previousFileIO = nullptr;
        std::unique_ptr<AZ::IO::LocalFileIO> fileIO;
        std::unique_ptr<AzFramework::AssetCatalog> catalog;
        std::unique_ptr<AZ::RHI::RHISystem> rhi;
        std::unique_ptr<AZ::RPI::ShaderSystem> shaders;
        AZ::RPI::AssetHandlerPtrList handlers;
        bool created = false, devicesAttempted = false, shadersInitialized = false;

        bool Start(const Options& o, rapidjson::Document& report)
        {
            AZ::ComponentApplication::Descriptor descriptor;
            for (const char* dll : {"Atom_RHI.Private.dll", "Atom_RHI_Vulkan.Private.dll"})
            {
                const auto path = fs::path(o.sdk) / dll;
                if (!fs::is_regular_file(path)) return false;
                AZ::DynamicModuleDescriptor module;
                module.m_dynamicLibraryPath = path.string().c_str();
                descriptor.m_modules.push_back(module);
            }
            AZ::ComponentApplication::StartupParameters startup;
            startup.m_loadStaticModules = false;
            startup.m_loadDynamicModules = true;
            startup.m_loadSettingsRegistry = false;
            startup.m_loadAssetCatalog = false;
            entity = application.Create(descriptor, startup);
            created = entity != nullptr;
            if (!created) return false;
            auto* settingsRegistry = AZ::SettingsRegistry::Get();
            if (!settingsRegistry || !settingsRegistry->Set(AZ::SettingsRegistryMergeUtils::FilePathKey_CacheRootFolder, o.products.c_str())) return false;
            previousFileIO = AZ::IO::FileIOBase::GetInstance();
            fileIO = std::make_unique<AZ::IO::LocalFileIO>();
            AZ::IO::FileIOBase::SetInstance(fileIO.get());
            fileIO->SetAlias("@products@", o.products.c_str());
            fileIO->SetAlias("@user@", o.user.c_str());

            auto* console = AZ::Interface<AZ::IConsole>::Get();
            if (!console) return false;
            for (const char* command : {"cl_jobThreadsConcurrencyRatio 0", "cl_jobThreadsMinNumber 1",
                 "cl_taskGraphThreadsConcurrencyRatio 0", "cl_taskGraphThreadsMinNumber 1", "cl_taskGraphThreadsMaxNumber 1"})
            {
                if (!console->PerformCommand(command).IsSuccess()) return false;
            }
            application.RegisterComponentDescriptor(AZ::JobManagerComponent::CreateDescriptor());
            application.RegisterComponentDescriptor(AZ::TaskGraphSystemComponent::CreateDescriptor());
            application.RegisterComponentDescriptor(AZ::StreamerComponent::CreateDescriptor());
            application.RegisterComponentDescriptor(AZ::AssetManagerComponent::CreateDescriptor());
            if (!entity->CreateComponent<AZ::JobManagerComponent>() ||
                !entity->CreateComponent<AZ::TaskGraphSystemComponent>() ||
                !entity->CreateComponent<AZ::StreamerComponent>() ||
                !entity->CreateComponent<AZ::AssetManagerComponent>()) return false;
            entity->Init();
            entity->Activate();
            AZ::JobManager* jobs = nullptr;
            AZ::JobManagerBus::BroadcastResult(jobs, &AZ::JobManagerBus::Events::GetManager);
            if (!jobs || jobs->GetNumWorkerThreads() != 1) return false;
            report.AddMember("jobWorkerThreads", jobs->GetNumWorkerThreads(), report.GetAllocator());
            report.AddMember("taskGraphConfiguredWorkers", 1, report.GetAllocator());
            if (!AZ::Data::AssetManager::IsReady() || !AZ::RHI::Factory::IsReady() ||
                (AZ::RHI::Factory::Get().GetType() != AZ::RHI::APIType("vulkan") ||
                 AZ::RHI::Factory::Get().GetAPIUniqueIndex() != 2)) return false;

            auto* serialize = application.GetSerializeContext();
            if (!serialize->FindClassData(azrtti_typeid<AZ::Name>())) AZ::Name::Reflect(serialize);
            AzFramework::AssetRegistry::ReflectSerialize(serialize);
            AZ::RPI::ShaderSystem::Reflect(serialize);
            rhi = std::make_unique<AZ::RHI::RHISystem>();
            devicesAttempted = true;
            if (rhi->InitDevices(1) != AZ::RHI::ResultCode::Success || rhi->GetDeviceCount() != 1 || !rhi->GetDevice()) return false;
            // Public no-bindless initialization is valid because this probe creates no SRG or draw.
            rhi->Init();
            auto& a = report.GetAllocator();
            Json backend(rapidjson::kObjectType);
            Text(backend, "name", AZ::RHI::Factory::Get().GetName().GetCStr(), a);
            backend.AddMember("typeCrc32", AZ::RHI::Factory::Get().GetType().GetValue(), a);
            Text(backend, "deviceName", rhi->GetDevice()->GetPhysicalDevice().GetDescriptor().m_description.c_str(), a);
            Text(backend, "deviceRtti", rhi->GetDevice()->RTTI_GetTypeName(), a);
            Text(backend, "deviceTypeId", TypeText(rhi->GetDevice()->RTTI_GetType()), a);
            backend.AddMember("deviceCount", rhi->GetDeviceCount(), a);
            backend.AddMember("apiIndex", AZ::RHI::Factory::Get().GetAPIUniqueIndex(), a);
            report.AddMember("backend", backend, a);
            AZ::RPI::ShaderSystem::GetAssetHandlers(handlers);
            shaders = std::make_unique<AZ::RPI::ShaderSystem>();
            shaders->Init();
            shadersInitialized = true;
            catalog = std::make_unique<AzFramework::AssetCatalog>(false);
            catalog->BusConnect();
            catalog->EnableCatalogForAsset(azrtti_typeid<AZ::RPI::ShaderAsset>());
            catalog->EnableCatalogForAsset(azrtti_typeid<AZ::RPI::ShaderVariantTreeAsset>());
            catalog->EnableCatalogForAsset(azrtti_typeid<AZ::RPI::ShaderVariantAsset>());
            Json services(rapidjson::kArrayType);
            for (const char* service : {"ComponentApplication", "JobsService", "TaskExecutorService", "DataStreamingService",
                 "AssetDatabaseService", "RHI.FactoryManager", "Vulkan.Factory", "RHI.RHISystem", "RPI.ShaderSystem", "AzFramework.AssetCatalog"})
                services.PushBack(Json(service, a), a);
            report.AddMember("services", services, a);
            bool catalogLoaded = false;
            AZ::Data::AssetCatalogRequestBus::BroadcastResult(
                catalogLoaded, &AZ::Data::AssetCatalogRequestBus::Events::LoadCatalog, o.catalog.c_str());
            return catalogLoaded;
        }
        ~Runtime()
        {
            if (shadersInitialized) shaders->Shutdown();
            shaders.reset();
            if (AZ::Data::AssetManager::IsReady()) AZ::Data::AssetManager::Instance().DispatchEvents();
            handlers.clear();
            if (AZ::Data::AssetManager::IsReady()) AZ::Data::AssetManager::Instance().DispatchEvents();
            catalog.reset();
            if (devicesAttempted) rhi->Shutdown();
            rhi.reset();
            // Preserve native module-before-system-entity deactivation inside Destroy().
            if (created) application.Destroy();
            if (fileIO) AZ::IO::FileIOBase::SetInstance(previousFileIO);
            fileIO.reset(); // ComponentApplication object (and its allocator ownership) remains alive.
        }
    };
    bool Identity(const Json& input, AZ::Data::AssetId& id, AZ::Uuid& type)
    {
        if (!input.IsObject() || !input.HasMember("guid") || !input["guid"].IsString() ||
            !input.HasMember("subId") || !input["subId"].IsUint() || !input.HasMember("type") || !input["type"].IsString()) return false;
        id = AZ::Data::AssetId(AZ::Uuid(input["guid"].GetString()), input["subId"].GetUint());
        type = AZ::Uuid(input["type"].GetString());
        return id.IsValid() && !type.IsNull();
    }
    const Json* FindRole(const Json& assets, const char* role)
    {
        const Json* found = nullptr;
        for (const auto& item : assets.GetArray())
            if (item.IsObject() && item.HasMember("role") && item["role"].IsString() && !std::strcmp(item["role"].GetString(), role))
            {
                if (found) return nullptr;
                found = &item;
            }
        return found;
    }
    bool CatalogIdentity(Runtime& runtime, const Json& input, const AZ::Data::AssetId& id, const AZ::Uuid& type)
    {
        if (!input.HasMember("productPath") || !input["productPath"].IsString()) return false;
        const auto path = input["productPath"].GetString();
        const auto info = runtime.catalog->GetAssetInfoById(id);
        return runtime.catalog->GetAssetIdByPath(path, type, false) == id && info.m_assetId == id &&
            info.m_assetType == type && info.m_relativePath == path && info.m_sizeBytes > 0;
    }
    bool Dependencies(Runtime& runtime, const AZ::Data::AssetId& id, Json& row, Allocator& a)
    {
        const auto dependencies = runtime.catalog->GetDirectProductDependencies(id);
        if (!dependencies.IsSuccess()) return false;
        Json items(rapidjson::kArrayType);
        for (const auto& dep : dependencies.GetValue())
        {
            Json item(rapidjson::kObjectType);
            const auto info = runtime.catalog->GetAssetInfoById(dep.m_assetId);
            Text(item, "id", IdText(dep.m_assetId), a);
            Text(item, "guid", TypeText(dep.m_assetId.m_guid), a);
            item.AddMember("subId", dep.m_assetId.m_subId, a);
            Text(item, "type", TypeText(info.m_assetType), a);
            Text(item, "productPath", info.m_relativePath.c_str(), a);
            item.AddMember("flags", static_cast<uint64_t>(dep.m_flags.to_ullong()), a);
            items.PushBack(item, a);
        }
        row.AddMember("directDependencies", items, a);
        return true;
    }
    template<class T>
    bool Load(Runtime& runtime, const Json& input, AZ::Data::Asset<T>& asset, Json& row, Allocator& a)
    {
        AZ::Data::AssetId id;
        AZ::Uuid type;
        if (!Identity(input, id, type)) return false;
        Text(row, "role", input["role"].GetString(), a);
        Text(row, "id", IdText(id), a);
        Text(row, "guid", TypeText(id.m_guid), a);
        row.AddMember("subId", id.m_subId, a);
        Text(row, "type", TypeText(type), a);
        Text(row, "productPath", input["productPath"].GetString(), a);
        if (type != azrtti_typeid<T>() || !CatalogIdentity(runtime, input, id, type))
        {
            Text(row, "status", "CatalogMismatch", a); row.AddMember("ready", false, a);
            return false;
        }
        asset = AZ::Data::AssetManager::Instance().GetAsset<T>(id, AZ::Data::AssetLoadBehavior::PreLoad);
        asset.BlockUntilLoadComplete();
        AZ::Data::AssetManager::Instance().DispatchEvents();
        Text(row, "status", asset.IsReady() ? "Ready" : asset.IsError() ? "Error" : "NotReady", a);
        row.AddMember("ready", asset.IsReady(), a);
        Text(row, "loadedGuid", TypeText(asset.GetId().m_guid), a);
        row.AddMember("loadedSubId", asset.GetId().m_subId, a);
        Text(row, "loadedType", TypeText(asset.GetType()), a);
        return asset.IsReady() && asset.GetId() == id && asset.GetType() == type && Dependencies(runtime, id, row, a);
    }
    bool Variant(const AZ::Data::Asset<AZ::RPI::ShaderVariantAsset>& variant, AZ::u32 stableId, Json& row, Allocator& a)
    {
        row.AddMember("stableId", variant->GetStableId().GetIndex(), a);
        if (variant->GetStableId().GetIndex() != stableId) return false;
        Json stages(rapidjson::kArrayType);
        for (unsigned stage = 0; stage < AZ::RHI::ShaderStageCount; ++stage)
        {
            const auto* function = variant->GetShaderStageFunction(static_cast<AZ::RHI::ShaderStage>(stage));
            if (!function) continue;
            const auto* vulkan = azrtti_cast<const AZ::Vulkan::ShaderStageFunction*>(function);
            if (!vulkan) return false;
            const auto bytes = vulkan->GetByteCode(AZ::Vulkan::ShaderSubStage::Default);
            uint32_t magic = 0;
            if (bytes.size() >= sizeof(magic)) std::memcpy(&magic, bytes.data(), sizeof(magic));
            Json entry(rapidjson::kObjectType);
            entry.AddMember("stage", stage, a);
            Text(entry, "type", function->RTTI_GetTypeName(), a);
            Text(entry, "typeId", TypeText(function->RTTI_GetType()), a);
            Text(entry, "backend", "vulkan", a);
            entry.AddMember("bytes", static_cast<uint64_t>(bytes.size()), a);
            entry.AddMember("spirvMagic", magic, a);
            stages.PushBack(entry, a);
            if (bytes.size() < 20 || bytes.size() % 4 || magic != 0x07230203u) return false;
        }
        if (stages.Empty()) return false;
        row.AddMember("stages", stages, a);
        return true;
    }
    int Probe(const Options& o, const rapidjson::Document& manifest, Runtime& runtime, rapidjson::Document& report)
    {
        auto& a = report.GetAllocator();
        if (o.mode == "negative-missing")
        {
            AZ::Data::AssetId id;
            AZ::Uuid type;
            if (!manifest.HasMember("negativeAsset") || !Identity(manifest["negativeAsset"], id, type) ||
                id != AZ::Data::AssetId(AZ::Uuid("{4D8AAC49-F4D1-4588-B771-E64FB725DA43}"), 0) ||
                type != azrtti_typeid<AZ::RPI::ShaderAsset>()) return Fail(report, "negative-catalog-lookup", "Invalid explicit negative identity", 3);
            Text(report, "negativeAssetId", IdText(id), a);
            Text(report, "negativeGuid", TypeText(id.m_guid), a);
            report.AddMember("negativeSubId", id.m_subId, a);
            if (runtime.catalog->GetAssetInfoById(id).m_assetId.IsValid()) return Fail(report, "negative-catalog-lookup", "Negative identity exists in catalog", 3);
            report["expectedNegative"].SetBool(true);
            return Fail(report, "negative-catalog-lookup", "Explicit test AssetId is absent from the real catalog", 20);
        }
        if (!manifest.HasMember("assets") || !manifest["assets"].IsArray() || manifest["assets"].Size() != ExpectedAssets.size())
            return Fail(report, "manifest", "Exactly six positive roles required", 3);
        for (const auto& expected : ExpectedAssets)
        {
            const auto* item = FindRole(manifest["assets"], expected.role);
            AZ::Data::AssetId id;
            AZ::Uuid type;
            if (!item || !Identity(*item, id, type) || id != AZ::Data::AssetId(AZ::Uuid(expected.guid), expected.subId) ||
                !item->HasMember("productPath") || !(*item)["productPath"].IsString())
                return Fail(report, "manifest", "Missing/duplicate role or unexpected AP85 identity", 3);
            const fs::path path((*item)["productPath"].GetString());
            if (path.empty() || path.is_absolute()) return Fail(report, "manifest", "Product path must be relative", 3);
            for (const auto& part : path) if (part == "..") return Fail(report, "manifest", "Product path escapes mount", 3);
            if (!fs::is_regular_file(fs::path(o.products) / path)) return Fail(report, "catalog", "Expected product file absent", 4);
        }
        AZ::Data::Asset<AZ::RPI::ShaderAsset> shader;
        AZ::Data::Asset<AZ::RPI::ShaderVariantTreeAsset> tree;
        std::array<AZ::Data::Asset<AZ::RPI::ShaderVariantAsset>, 4> variants;
        Json shaderRow(rapidjson::kObjectType);
        bool ok = Load(runtime, *FindRole(manifest["assets"], "shader"), shader, shaderRow, a);
        if (ok)
        {
            // ShaderAssetHandler selected the active Factory during its normal LoadAssetData.
            // GetCurrentShaderApiData is private: observe the selected public root instead.
            const auto selectedRoot = shader->GetRootVariantAsset(AZ::RPI::SupervariantIndex{0});
            ok = selectedRoot.IsReady() && selectedRoot.GetId() ==
                AZ::Data::AssetId(AZ::Uuid(ExpectedAssets[1].guid), ExpectedAssets[1].subId) &&
                (selectedRoot.GetId().m_subId >> 30) == AZ::RHI::Factory::Get().GetAPIUniqueIndex() &&
                shader->GetPipelineLayoutDescriptor(AZ::RPI::SupervariantIndex{0});
            shaderRow.AddMember("apiSelectedCrc32", AZ::RHI::Factory::Get().GetType().GetValue(), a);
            Text(shaderRow, "selectedRootId", IdText(selectedRoot.GetId()), a);
            shaderRow.AddMember("selectedRootApiIndex", selectedRoot.GetId().m_subId >> 30, a);
        }
        report["assets"].PushBack(shaderRow, a);
        if (!ok) return Fail(report, "asset-load", "Shader not Ready/selected Vulkan/layout invalid", 5);
        Json treeRow(rapidjson::kObjectType);
        ok = Load(runtime, *FindRole(manifest["assets"], "tree"), tree, treeRow, a);
        if (ok) treeRow.AddMember("nodeCount", static_cast<uint64_t>(tree->GetNodeCount()), a);
        report["assets"].PushBack(treeRow, a);
        if (!ok || tree->GetNodeCount() == 0) return Fail(report, "asset-load", "Variant tree not Ready/nonempty", 5);
        for (unsigned index = 0; index < variants.size(); ++index)
        {
            const char* role = ExpectedAssets[index ? index + 2 : 1].role;
            Json row(rapidjson::kObjectType);
            ok = Load(runtime, *FindRole(manifest["assets"], role), variants[index], row, a);
            if (ok) ok = Variant(variants[index], index, row, a);
            report["assets"].PushBack(row, a);
            if (!ok) return Fail(report, "asset-load", "Variant Ready/stableId/Vulkan SPIR-V verification failed", 5);
        }
        const auto shaderRoot = shader->GetRootVariantAsset(AZ::RPI::SupervariantIndex{0});
        if (!shaderRoot.IsReady() || shaderRoot.GetId() != variants[0].GetId() || shaderRoot.Get() != variants[0].Get())
            return Fail(report, "runtime-object", "Shader root does not reference expected AP85 root", 6);
        // Same public post-load bus used by RPISystem::SimulationTick, without creating a scene/frame.
        AZ::RPI::AssetInitBus::Broadcast(&AZ::RPI::AssetInitBus::Events::PostLoadInit);
        auto instance = AZ::RPI::Shader::FindOrCreate(shader);
        if (!instance || instance->GetAsset().GetId() != shader.GetId()) return Fail(report, "runtime-object", "Shader::FindOrCreate failed", 6);
        report["shaderInstanceCreated"].SetBool(true);
        Text(report, "shaderInstanceAssetId", IdText(instance->GetAsset().GetId()), a);
        instance = nullptr;
        return 0;
    }
}

int main(int argc, char** argv)
{
    #if defined(_WIN32)
    const DWORD previousErrorMode = SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
    #endif
    Options options;
    rapidjson::Document report(rapidjson::kObjectType);
    auto& a = report.GetAllocator();
    Text(report, "schema", "je-shader-runtime86-result-v2", a);
    Text(report, "mode", "", a); Text(report, "stage", "arguments", a); Text(report, "error", "", a);
    report.AddMember("ok", false, a); report.AddMember("expectedNegative", false, a);
    report.AddMember("cleanupComplete", false, a); report.AddMember("shaderInstanceCreated", false, a);
    report.AddMember("noWindowOrDraw", true, a); report.AddMember("assets", Json(rapidjson::kArrayType), a);
    int code = 2;
    try
    {
        if (!ParseOptions(argc, argv, options)) Fail(report, "arguments", "Required: --mode positive|negative-missing --sdk-bin --products-root --catalog --manifest --user-root", 2);
        else
        {
            ReplaceText(report, "mode", options.mode, a);
            for (const auto* path : {&options.sdk, &options.products, &options.catalog, &options.manifest, &options.user})
                if (!fs::path(*path).is_absolute()) throw std::runtime_error("All paths must be absolute");
            if (!fs::equivalent(fs::current_path(), options.products) || !fs::is_directory(options.user))
                throw std::runtime_error("cwd must equal products-root; private user-root must already exist");
            std::ifstream input(options.manifest, std::ios::binary);
            std::ostringstream contents; contents << input.rdbuf();
            rapidjson::Document manifest; manifest.Parse(contents.str().c_str());
            if (!input || manifest.HasParseError() || !manifest.IsObject() || !manifest.HasMember("schema") ||
                !manifest["schema"].IsString() || std::strcmp(manifest["schema"].GetString(), "je-shader-runtime86-v1"))
                code = Fail(report, "manifest", "Invalid real product manifest", 3);
            else
            {
                TraceObserver trace;
                {
                    Runtime runtime;
                    if (!runtime.Start(options, report)) code = Fail(report, "bootstrap", "Native services/catalog/Vulkan initialization failed", 4);
                    else if (trace.assertions.load() || trace.errors.load() || trace.exceptions.load())
                        code = Fail(report, "native-diagnostic", "Native bootstrap diagnostic observed", 7);
                    else
                    {
                        code = Probe(options, manifest, runtime, report);
                        if (!CaptureModules(report))
                            code = Fail(report, "module-snapshot", "Win32 module snapshot failed; runtime evidence unavailable", 9);
                    }
                }
                report["cleanupComplete"].SetBool(true);
                report.AddMember("assertions", trace.assertions.load(), a); report.AddMember("errors", trace.errors.load(), a);
                report.AddMember("exceptions", trace.exceptions.load(), a);
                if (trace.assertions.load() || trace.errors.load() || trace.exceptions.load())
                    code = Fail(report, "native-diagnostic", "Recorded native assert/error/exception; never accepted as success", 7);
            }
        }
    }
    catch (const std::exception& error) { code = Fail(report, "exception", error.what(), 8); }
    report["ok"].SetBool(code == 0);
    if (code == 0) ReplaceText(report, "stage", "complete", a);
    report.AddMember("exitCode", code, a);
    rapidjson::StringBuffer buffer;
    rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
    report.Accept(writer);
    std::printf("JE_SHADER_RUNTIME86_RESULT=%s\n", buffer.GetString());
    #if defined(_WIN32)
    SetErrorMode(previousErrorMode);
    #endif
    return code;
}
