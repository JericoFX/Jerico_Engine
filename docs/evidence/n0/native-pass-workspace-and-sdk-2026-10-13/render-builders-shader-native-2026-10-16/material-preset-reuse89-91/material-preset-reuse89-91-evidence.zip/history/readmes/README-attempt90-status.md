# Reutilización de presets existentes: material89/90

Evidencia delimitada de la integración nativa. Los JSON y scripts conservan su estado histórico; el cierre vigente se resume aquí y en el manifiesto. Esta selección es provisional. El intento90 terminó con fallo adicional; el control manual y GUI90 en un proceso nuevo siguen pendientes. Todavía no se creó el ZIP final.

- **RED88:** cinco casos reales, un fallo causal al repetir `EnsureTexturePresetIfUnset` sobre el sidecar nativo compatible y cuatro controles correctos. El XML y el código de salida nativo se conservan; el wrapper permitió ese fallo intencional.
- **GREEN89:** los mismos cinco casos pasan. El build focal reutilizado y los hosts Editor/AP/AssetBuilder tienen sus resultados reales separados. Los intentos de preparación fallidos se conservan con su estado original.
- **Control manual89:** un caso adicional falló antes de comprobar el preset porque su imagen era un puntero LFS de 128 bytes, no el PNG de 598 bytes. Se conserva el puntero y el fallo original. El cambio test-only90 crea un PNG real de 32×32 en el directorio temporal ya existente; mantiene los oráculos posteriores y no descarga ni sustituye el asset LFS del repositorio.
- **GUI89 aceptada por el padre:** clic derecho → Generar material sobre el PNG de la fixture existente, material nuevo abierto en el mismo Workspace, Shaderball visible, edición de vertex color, Undo/Redo, Save y reapertura del panel con Shaderball rojo. Las siete capturas originales y las acciones del padre están incluidas. La reapertura ocurrió en el mismo PID Editor18824; no demuestra reinicio de proceso.
- **Cook focal GUI89:** el AP conserva dos ciclos Processing/Processed de ese material. Los logs actuales CreateJobs/Process pertenecen al segundo, RunKey97674, con cero errores y avisos. El segundo ciclo aparece después del guardado en el registro de la sesión; se preservan los timestamps crudos y la discrepancia entre reloj AP, Editor y mtime. No se calcula latencia con esos relojes distintos.

La fuente guardada tiene 1.818 bytes, SHA256 `09B36BFE1B1BC48A8868B5A4008F3812100537DB14E99440BD412E1589D7CCA9`, tipo StandardPBR versión6 y `vertexColor.enable=true`. El producto `.azmaterial` focal tiene 5.850 bytes, SHA256 `2F763F95948C317494D2DA1107EDFBEB972983E17BD5DF56DBD69ED2144B7571`. Las siete entradas originales de la fixture suman 346.829 bytes; se conservan sus PNG y sidecars exactos. No se incluye un volcado del Cache ni de texturas del propietario.

El postflight GUI89 verificó 14.034 inputs, 40 archivos de autoría protegidos, 26 archivos del propietario, siete entradas de fixture, nueve binarios y la escena: cero diferencias. La captura puntual de módulos contiene los nueve pins esperados, incluida `ImageProcessingAtom.Editor.dll` con la corrección. Editor terminó normalmente0, sin guard RAM; la ausencia posterior de hijos no equivale a observar su código de salida. El pico muestreado de RAM física global fue59,71%, sin interpretación de benchmark.

## Contenido y reproducción

`native/` conserva XML, stdout/stderr, starts, resultados, freezes y postflights cerrados; `product-change/` contiene las cuatro preimágenes/candidatos productivos y diff/inversa; `test88-causal-regression/` conserva ambas revisiones del test causal; `test90-png-fixture-fix/` conserva el cambio de fixture y su aplicación. `gui89/` incluye preparación, capturas, acciones, módulos, fuente guardada, producto focal, fixture7 y logs crudos. `reproduction/` conserva los scripts exactos; sus rutas absolutas y requisitos son históricos, no un lanzador portátil ni una autorización para ejecutarlos.

La selección registra original→ruta relativa, bytes y SHA256 de cada copia. Los diffs e inversas y sus comprobaciones byteexactas se preservan sin aplicar nada. La investigación primaria del PR O3DE4611 está en `product-change/upstream-review.md`: respalda nombres de preset y compatibilidad UUID heredada; no sustituye la corrección local ni sus pruebas.

## Pendientes y límites

1. Resolver y verificar el control manual pendiente. El intento90 ya se conserva como RED adicional: seis casos, cinco correctos y uno fallido; no es GREEN. Cinco y seis no deben sumarse como once identidades distintas.
2. Incorporar GUI90 en un **nuevo proceso**, con lectura del material guardado, módulos actuales, capturas, cierre y postflight del padre.
3. Con ambos gates cerrados, sellar una sola vez el ZIP y reabrir cada entrada para comprobar nombre relativo, bytes y SHA256 contra la selección final.

El árbol de integración contiene WIP preservado: no se ejecutó un replay limpio sobre HEAD ni se prueba independencia de otros cambios. No hay PASS global de los347 fallos AP heredados, incremento de Gems, aceptación VR/Linux/Shipping ni cierre global de dependencias. Las advertencias y errores registrados por el Editor no se borran ni se presentan como inexistentes. Los resultados de esta selección no autorizan otra prueba ni cambian sus criterios.

## Intento90 cerrado: RED adicional, no GREEN

Build nativo0 en23,929s. El XML contiene seis identidades: los cinco casos TextureSetPreset pasan y el único control manual falla en la línea1143, en `actual->second.Equals(settings, m_context.get())` después de reabrir. El PNG ya carga; este fallo es distinto del puntero LFS del intento89. No se repitió ni se ocultó el fallo y todavía no se atribuye a un campo concreto. El nombre histórico de la carpeta `green-native90-attempt1` no convierte su resultado en GREEN.

XML SHA256: `9A3C073E3C9AF4C43CB4404931E6A1A10F8212A5CDA2517562C4B45022DBF416`. Recibo terminal Luna SHA256: `65FC74EC73121680D878B0773234AD7391B4B6486E345F7CEC6021C69330D7C6`; registra14034 inputs sin deriva y protecciones40/26/7/9 intactas. No se repitió el rehash completo al preparar este append. GUI90 sigue sin lanzar; su preparación no acredita ejecución ni lectura del material en otro proceso.

Los181 archivos previos y su selección permanecen byteexactos. Este resumen sustituye sólo el estado provisional del README anterior; el cierre final y el ZIP siguen pendientes de revisión del padre.
