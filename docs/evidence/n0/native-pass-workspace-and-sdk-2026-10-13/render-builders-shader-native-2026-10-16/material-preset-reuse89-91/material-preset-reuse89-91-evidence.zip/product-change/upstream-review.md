# PR O3DE 4611: nombres de preset y compatibilidad heredada

Revisión: 2026-10-16. Evidencia de lectura; ningún código importado, compilado ni ejecutado.

## Revisión exacta

El PR [ATOM-16575 clean up image builder presets files](https://github.com/o3de/o3de/pull/4611) está cerrado y fusionado el 2021-10-11 a las 22:18:39 UTC. La [respuesta primaria de GitHub](https://api.github.com/repos/o3de/o3de/pulls/4611) identifica:

- Head: `28cf51c51be0cbc0af70b29f5218e96182e57310`.
- Merge: `89e6df1c7fc6105ab6fac70964415af283768912`.
- Tres commits y 81 archivos modificados.

Se revisó la [lista completa y sus parches, 81 entradas en una página](https://api.github.com/repos/o3de/o3de/pulls/4611/files?per_page=100), además de los archivos pertinentes fijados al head. La vista HTML de los hunks no cargaba completamente; la API REST y los textos raw primarios permitieron contrastarlos sin clonar el repositorio.

## Qué demuestra el cambio

En [TextureSettings.cpp del head](https://github.com/o3de/o3de/blob/28cf51c51be0cbc0af70b29f5218e96182e57310/Gems/Atom/Asset/ImageProcessingAtom/Code/Source/BuilderSettings/TextureSettings.cpp), la reflexión pasa de versión 1 a 2: conserva `PresetID` para el UUID heredado y añade `Preset` para el nombre. `ApplyPreset` pasa a recibir el nombre. En `LoadTextureSetting` (líneas 193–211), después de cargar el objeto nativo, las líneas 206–208 resuelven el UUID mediante `GetPresetNameFromId` solamente cuando el nombre está vacío. El [header de esa misma revisión](https://github.com/o3de/o3de/blob/28cf51c51be0cbc0af70b29f5218e96182e57310/Gems/Atom/Asset/ImageProcessingAtom/Code/Source/BuilderSettings/TextureSettings.h) conserva ambos campos.

[BuilderSettingManager.cpp, líneas 170–182](https://github.com/o3de/o3de/blob/28cf51c51be0cbc0af70b29f5218e96182e57310/Gems/Atom/Asset/ImageProcessingAtom/Code/Source/BuilderSettings/BuilderSettingManager.cpp#L170-L182) busca el UUID entre los presets cargados y devuelve su nombre; si no encuentra coincidencia devuelve un nombre vacío. Esto respalda reutilizar el contrato nombre/UUID heredado, pero no permite considerar válido un UUID desconocido. El PR elimina las consultas de preset por UUID y cambia la selección sugerida a nombres; no aporta una política de adopción de sidecars existentes.

## Aplicabilidad y límites para el bloqueo actual

El paquete local de W1 identifica `EnsureTexturePresetIfUnset` en `Gems/Atom/Asset/ImageProcessingAtom/Code/Source/ImageProcessingSystemComponent.cpp`, líneas 131–281, con rechazo general por existencia en 177–180. Pin de ese archivo consultado: `77A3024C6CD3D57C655716CE81BF7A3DBBA72A63E65195ABE11F133FC8695EA4`. Es evidencia local reutilizada, no un archivo modificado por este trabajo.

Ninguno de los 81 parches del PR modifica ese componente ni introduce `EnsureTexturePresetIfUnset` o `HasPlatformOverride`. Por tanto, el PR no resuelve la repetición sobre un `.assetinfo` nativo compatible, ni demuestra que un sidecar manual sea compatible. `WriteTextureSetting` del head (líneas 214–221) serializa mediante el guardado XML nativo; no establece creación exclusiva ni una comprobación de compatibilidad sin escritura. Reaplicar un preset para comprobarlo alteraría datos: la revisión local debe preservar base y overrides efectivos y resolver sus nombres sin reescribirlos.

El PR tampoco aporta reparación demostrada de parches inválidos o teardown. En `GetPlatformSpecificTextureSetting` del mismo head, línea 254 recibe el resultado de `DataPatch::Apply` y la línea 255 lo desreferencia para comprobar el array de mipmaps; el bloque no verifica antes un resultado nulo. Esa observación estática delimita lo que falta en ese cambio upstream; por sí sola no demuestra una AV local ni autoriza una reparación.

La compatibilidad actual, el fallo silencioso convertido en aviso inline y la preservación exacta de XML deben comprobarse con los tests locales y la repetición GUI asignados por el padre. Esta lectura no sustituye RED/GREEN, no acepta cook/render, no incorpora código upstream y no incrementa Gems aceptadas.
