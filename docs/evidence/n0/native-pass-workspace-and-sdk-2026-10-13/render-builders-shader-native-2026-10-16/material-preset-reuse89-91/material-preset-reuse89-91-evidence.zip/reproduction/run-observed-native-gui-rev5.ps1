param(
    [Parameter(Mandatory)][ValidateSet('Editor','GameLauncher')][string]$Kind,
    [Parameter(Mandatory)][ValidateSet('vulkan','dx12')][string]$Backend,
    [Parameter(Mandatory)][string]$EvidenceName,
    [Parameter(Mandatory)][string]$SourceFreezePath,
    [Parameter(Mandatory)][string]$SourceFreezeSHA256
)
$ErrorActionPreference='Stop'
$jeRepo='F:\JericoEngine\JericoEngine'
$jeArea=Join-Path $jeRepo 'build/n0-validation/native-render-builders-integration-rev1'
if($EvidenceName -notmatch '^[a-z0-9-]+$'){throw 'Invalid evidence subdirectory name.'}
$jeDest=Join-Path $jeArea $EvidenceName
if(Test-Path -LiteralPath $jeDest){throw 'Preserve prior native run.'}
$jeOs=Get-CimInstance Win32_OperatingSystem
$jeRam=100*(1-$jeOs.FreePhysicalMemory/$jeOs.TotalVisibleMemorySize)
if($jeRam -ge 70 -or ($jeOs.FreePhysicalMemory/1MB) -lt 10){throw 'Native admission requires RAM <70% and >=10 GiB free.'}
$jeNative=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^(Editor|JEEditorFixture.GameLauncher|AssetProcessorBatch|MSBuild|cmake|cl|link|AzTestRunner|JENativeSdkConsumer)\.exe$'})
if($jeNative.Count){throw 'Another native validation is active.'}
if($Kind -eq 'GameLauncher' -and (Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^(AssetProcessor|AssetBuilder)\.exe$'})){throw 'No-AP runtime gate requires AP absent.'}
$jeFreezePath=[IO.Path]::GetFullPath($SourceFreezePath)
if((Get-FileHash -LiteralPath $jeFreezePath).Hash -ne $SourceFreezeSHA256){throw 'Freeze identity drift.'}
$jeFreeze=Get-Content -LiteralPath $jeFreezePath -Raw | ConvertFrom-Json
foreach($jeEntry in $jeFreeze.sourceInputs){if((Get-Item -LiteralPath $jeEntry.path).Length -ne $jeEntry.bytes -or (Get-FileHash -LiteralPath $jeEntry.path).Hash -ne $jeEntry.sha256){throw "Source drift: $($jeEntry.path)"}}
$jeProtectedPath=Join-Path $jeRepo 'build/n0-validation/native-passgraph-workspace-rev1/real-pass-editor-ap-attempt1/protected-authored-preflight.json'
$jeProtected=(Get-Content -LiteralPath $jeProtectedPath -Raw | ConvertFrom-Json).inputs
foreach($jeEntry in $jeProtected){if((Get-Item -LiteralPath $jeEntry.path).Length -ne $jeEntry.bytes -or (Get-FileHash -LiteralPath $jeEntry.path).Hash -ne $jeEntry.sha256){throw "Authored drift: $($jeEntry.path)"}}
$jeBin=Join-Path $jeRepo 'build/n0-validation/original-engine/bin/profile'
$jeExe=Join-Path $jeBin $(if($Kind -eq 'Editor'){'Editor.exe'}else{'JEEditorFixture.GameLauncher.exe'})
$jeArgs=@('--project-path','F:/JericoEngine/JericoEngine/Projects/JEEditorFixture',('--rhi='+$Backend))
if($Kind -eq 'Editor'){$jeArgs += @('--skipWelcomeScreen','F:/JericoEngine/JericoEngine/Projects/JEEditorFixture/Levels/JEMaterialCookNative5/JEMaterialCookNative5.prefab')}
else{$jeArgs += @('--bg_ConnectToAssetProcessor=false','--regset=/Amazon/AzCore/Bootstrap/wait_for_connect=0','--regset=/Amazon/AzCore/Bootstrap/remote_filesystem=0')}
$jeCwd=if($Kind -eq 'Editor'){$jeRepo}else{$jeBin}
$jeOs=Get-CimInstance Win32_OperatingSystem;$jeRam=100*(1-$jeOs.FreePhysicalMemory/$jeOs.TotalVisibleMemorySize)
if($jeRam -ge 70 -or ($jeOs.FreePhysicalMemory/1MB) -lt 10){throw 'Native admission requires RAM <70% and >=10 GiB free.'}
New-Item -ItemType Directory -Path $jeDest | Out-Null
$jeTimer=[Diagnostics.Stopwatch]::StartNew()
$jeProc=Start-Process -FilePath $jeExe -ArgumentList $jeArgs -WorkingDirectory $jeCwd -WindowStyle Normal -RedirectStandardOutput (Join-Path $jeDest 'native.stdout.log') -RedirectStandardError (Join-Path $jeDest 'native.stderr.log') -PassThru
$jeInfo=Get-CimInstance Win32_Process -Filter ('ProcessId='+$jeProc.Id)
$jeStart=[ordered]@{utc=[datetime]::UtcNow.ToString('o');owner='/root';nativeOwner='/root';kind=$Kind;backend=$Backend;pid=$jeProc.Id;creationUtc=$jeInfo.CreationDate.ToUniversalTime().ToString('o');executable=$jeExe;argv=$jeArgs;cwd=$jeCwd;exeSHA256=(Get-FileHash -LiteralPath $jeExe).Hash;editorMaterialsSHA256=(Get-FileHash -LiteralPath (Join-Path $jeBin 'EditorMaterials.dll')).Hash;nativeBuilderSHA256=(Get-FileHash -LiteralPath (Join-Path $jeBin 'RenderAssetBuilders.dll')).Hash;freezeSHA256=(Get-FileHash -LiteralPath $jeFreezePath).Hash;sourceCount=$jeFreeze.sourceInputs.Count;protectedCount=$jeProtected.Count;ramBeforePercent=[math]::Round($jeRam,2);environment='Inherited task PowerShell environment; no new PATH/toolchain/global setting mutation.';nativeExitObserver=$true;launchNormalForAuthorizedInteractiveVisualCheck=$true;profileNotShipping=$true}
$jeStart | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $jeDest 'native-start.json') -Encoding utf8NoBOM
Write-Output ($jeStart | ConvertTo-Json -Depth 6)
$jeSamples=[Collections.Generic.List[object]]::new()
$jeStoppedByGuard=$false
try{
    while(!$jeProc.WaitForExit(3000)){
        $jeOs=Get-CimInstance Win32_OperatingSystem;$jeRam=100*(1-$jeOs.FreePhysicalMemory/$jeOs.TotalVisibleMemorySize)
        $jeProc.Refresh();$jeSamples.Add(@{utc=[datetime]::UtcNow.ToString('o');ramPercent=[math]::Round($jeRam,2);workingSetBytes=$jeProc.WorkingSet64;privateBytes=$jeProc.PrivateMemorySize64})
        if($jeRam -ge 80){
            $jeCurrent=Get-CimInstance Win32_Process -Filter ('ProcessId='+$jeProc.Id)
            if($jeCurrent.ExecutablePath -ne $jeInfo.ExecutablePath -or $jeCurrent.CreationDate -ne $jeInfo.CreationDate){throw 'Owned process identity drift.'}
            $jeStoppedByGuard=$true;$jeProc.Kill($true);$jeProc.WaitForExit();break
        }
    }
    $jeProc.WaitForExit();$jeExit=$jeProc.ExitCode
    [IO.File]::WriteAllText((Join-Path $jeDest 'native-exit.txt'),[string]$jeExit)
    $jeResult=[ordered]@{utc=[datetime]::UtcNow.ToString('o');owner='/root';pid=$jeStart.pid;creationUtc=$jeStart.creationUtc;nativeExit=$jeExit;elapsedSeconds=$jeTimer.Elapsed.TotalSeconds;stoppedByRamGuard=$jeStoppedByGuard;samples=@($jeSamples);stdoutSHA256=(Get-FileHash -LiteralPath (Join-Path $jeDest 'native.stdout.log')).Hash;stderrSHA256=(Get-FileHash -LiteralPath (Join-Path $jeDest 'native.stderr.log')).Hash;ownProcessHasExited=$jeProc.HasExited;ownPIDStillPresent=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+$jeStart.pid)).Count -ne 0;noProductAcceptanceFromExitAlone=$true}
    $jeResult|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $jeDest 'native-result.json') -Encoding utf8NoBOM
    Write-Output ($jeResult|ConvertTo-Json -Depth 7)
}finally{$jeProc.Dispose()}
