[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [switch]$Reconfigure,
    [switch]$AllowTestFailures,
    [string]$NativeAPFilter,
    [string]$IndependentNativeRoot,
    [switch]$SkipFocalBuild,
    [string]$ReuseBuildResultPath,
    [string]$ReuseConfigureResultPath,
    [string]$ReuseConfigureCachePath,
    [switch]$HostsOnly,
    [string]$ReuseFocalReviewPath,
    [string]$ReuseFocalReviewSHA256,
    [string]$ReuseFocalPostflightPath,
    [Parameter(Mandatory = $true)][string]$IntegratedFreezePath,
    [Parameter(Mandatory = $true)][string]$IntegratedFreezeSHA256,
    [Parameter(Mandatory = $true)][int]$InputCount,
    [Parameter(Mandatory = $true)][string]$EvidenceDirectory,
    [Parameter(Mandatory = $true)][string[]]$FocalTargets,
    [Parameter(Mandatory = $true)][string[]]$FocalCTestNames,
    [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]]$HostTargets,
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]]$HostCTestNames,
    [ValidateRange(1,100)][int]$RamGuardPercent = 80
)

$ErrorActionPreference = 'Stop'
$script:fatal = $null
$script:phases = [System.Collections.Generic.List[object]]::new()
$script:configureResult = $null
$repo = [IO.Path]::GetFullPath($Repository)
$freezePath = [IO.Path]::GetFullPath($IntegratedFreezePath)
$evidence = [IO.Path]::GetFullPath($EvidenceDirectory)
$build = Join-Path $repo 'build\n0-validation\original-engine'
$cache = Join-Path $build 'CMakeCache.txt'
$cmake = 'C:\Program Files\CMake\bin\cmake.exe'
$ctest = 'C:\Program Files\CMake\bin\ctest.exe'

if (Test-Path -LiteralPath $evidence) {
    if (@(Get-ChildItem -LiteralPath $evidence -Force).Count -gt 0) {
        throw "Evidence directory is not fresh: $evidence"
    }
} else {
    New-Item -ItemType Directory -Path $evidence | Out-Null
}
if ((Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash -cne $IntegratedFreezeSHA256) {
    throw 'Integrated freeze hash mismatch'
}
$freeze = Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
if ($freeze.inputs.Count -ne $InputCount) {
    throw "Unexpected integrated freeze count: expected=$InputCount actual=$($freeze.inputs.Count)"
}
if ($FocalTargets.Count -eq 0 -or $FocalCTestNames.Count -eq 0) {
    throw 'Focal target/test arrays must be explicit and non-empty before native execution'
}

function Save-Json([string]$Path, $Value) {
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
}

function Get-InputMap {
    $map = [ordered]@{}
    foreach ($entry in $freeze.inputs) {
        $path = [string]$entry.path
        if (-not [IO.Path]::IsPathRooted($path)) { $path = Join-Path $repo $path }
        $path = [IO.Path]::GetFullPath($path)
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Frozen input missing: $path" }
        $item = Get-Item -LiteralPath $path
        $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
        if ($item.Length -ne [long]$entry.bytes -or $hash -cne [string]$entry.sha256) {
            throw "Frozen input mismatch: $path"
        }
        $map[$path] = [pscustomobject]@{ bytes = $item.Length; sha256 = $hash }
    }
    return $map
}

function Get-OfflineCacheState {
    $lines = Get-Content -LiteralPath $cache
    $required = @(
        'CMAKE_GENERATOR:INTERNAL=Visual Studio 17 2022',
        'CMAKE_GENERATOR_PLATFORM:INTERNAL=x64',
        'FETCHCONTENT_FULLY_DISCONNECTED:BOOL=ON',
        'LY_PACKAGE_SERVER_URLS:STRING=',
        'O3DE_EXTERNAL_SUBDIRS:STRING=',
        'LY_PROJECTS:STRING=F:/JericoEngine/JericoEngine/Projects/JEEditorFixture'
    )
    $missing = @($required | Where-Object { $_ -cnotin $lines })
    [pscustomobject]@{
        path = $cache
        sha256 = (Get-FileHash -LiteralPath $cache -Algorithm SHA256).Hash
        requiredLines = $required
        missingLines = $missing
        valid = ($missing.Count -eq 0)
    }
}

function Get-RamSnapshot {
    $os = Get-CimInstance Win32_OperatingSystem
    $totalKb = [double]$os.TotalVisibleMemorySize
    $freeKb = [double]$os.FreePhysicalMemory
    $usedPercent = if ($totalKb -gt 0) { [Math]::Round((($totalKb - $freeKb) / $totalKb) * 100, 2) } else { 100.0 }
    [pscustomobject]@{
        capturedUtc = [DateTime]::UtcNow.ToString('o')
        totalBytes = [long]($totalKb * 1KB)
        freeBytes = [long]($freeKb * 1KB)
        usedPercent = $usedPercent
        thresholdPercent = $RamGuardPercent
    }
}
function Save-PhaseProcessSnapshot([string]$Base, [int]$RootId, [datetime]$RootCreationUtc, [string]$RootExecutable, $Ram) {
    $rows = @(Get-CimInstance Win32_Process)
    $byId = @{}
    foreach ($row in $rows) { $byId[[int]$row.ProcessId] = $row }
    $owned = [Collections.Generic.HashSet[int]]::new()
    $root = $byId[$RootId]
    if ($root -and $root.CreationDate -and $root.ExecutablePath -ieq $RootExecutable -and
        [Math]::Abs(($root.CreationDate.ToUniversalTime() - $RootCreationUtc).TotalMilliseconds) -lt 1) {
        [void]$owned.Add($RootId)
    }
    do {
        $added = $false
        foreach ($row in $rows) {
            if ($owned.Contains([int]$row.ParentProcessId) -and
                $row.CreationDate -and $byId[[int]$row.ParentProcessId].CreationDate -and
                $row.CreationDate -ge $byId[[int]$row.ParentProcessId].CreationDate -and
                $row.CreationDate.ToUniversalTime() -ge $RootCreationUtc -and
                $owned.Add([int]$row.ProcessId)) { $added = $true }
        }
    } while ($added)
    $nativeNames = @('cmake.exe','MSBuild.exe','cl.exe','Tracker.exe','link.exe','ctest.exe','AzTestRunner.exe','mspdbsrv.exe')
    $selected = @($rows | Where-Object {
        $owned.Contains([int]$_.ProcessId) -or $_.Name -in $nativeNames -or [long]$_.WorkingSetSize -ge 250MB
    })
    $snapshot = [ordered]@{
        capturedUtc = [datetime]::UtcNow.ToString('o'); ramUsedPercent = $Ram.usedPercent
        phaseRootId = $RootId; phaseRootCreationUtc = $RootCreationUtc.ToString('o')
        processes = @($selected | ForEach-Object {
            $isOwned = $owned.Contains([int]$_.ProcessId)
            $command = [string]$_.CommandLine
            [pscustomobject]@{
                pid = $_.ProcessId; parent = $_.ParentProcessId; name = $_.Name
                creationUtc = if ($_.CreationDate) { $_.CreationDate.ToUniversalTime().ToString('o') } else { $null }
                executable = $_.ExecutablePath
                workingSetBytes = [long]$_.WorkingSetSize; privateBytes = [long]$_.PrivatePageCount
                observedPhaseDescendant = $isOwned
                commandLine = if ($isOwned) { $command } else { $null }
                mentionsAuthoritativeCheckout = $command.Replace('/','\').IndexOf($repo,[StringComparison]::OrdinalIgnoreCase) -ge 0
                mentionsHawken = $command.IndexOf('Hawken',[StringComparison]::OrdinalIgnoreCase) -ge 0
            }
        })
    }
    [IO.File]::AppendAllText(($Base + '.memory-process-samples.jsonl'),($snapshot | ConvertTo-Json -Depth 5 -Compress) + [Environment]::NewLine,[Text.UTF8Encoding]::new($false))
    return $snapshot
}
function Invoke-Phase([string]$Name, [string]$Executable, [string[]]$PhaseArguments, [switch]$AllowNonZero, [string]$WorkingDirectory) {
    $ramBefore = Get-RamSnapshot
    if ($ramBefore.usedPercent -ge $RamGuardPercent) { throw ("RAM guard blocks {0}: {1}% >= {2}%" -f $Name, $ramBefore.usedPercent, $RamGuardPercent) }
    $started = [DateTime]::UtcNow
    $base = Join-Path $evidence $Name
    $stdoutPath = $base + '.stdout.log'
    $stderrPath = $base + '.stderr.log'
    $psi = [Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $Executable
    $psi.WorkingDirectory = if ($WorkingDirectory) { $WorkingDirectory } else { $repo }
    $psi.UseShellExecute = $false
    if ($Name.StartsWith('build-', [StringComparison]::Ordinal)) {
        # Task-local compiler concurrency: _CL_ is appended after command-line options.
        # /MP1 also limits compilation within the single MSBuild project; no cache/global edit.
        $inheritedTail = [string]$psi.Environment['_CL_']
        $psi.Environment['_CL_'] = ($inheritedTail + ' /MP1').Trim()
        $psi.Environment['MSBUILDDISABLENODEREUSE'] = '1'
    }
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    foreach ($argument in $PhaseArguments) { [void]$psi.ArgumentList.Add([string]$argument) }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $psi
    $stdoutStream = $null
    $stderrStream = $null
    try {
    $admission = Get-RamSnapshot
    if ($admission.usedPercent -ge 70 -or $admission.freeBytes -lt 10GB) {
        throw ("Phase admission blocks {0}: {1}% RAM, {2} free bytes; requires <70% and >=10 GiB" -f $Name, $admission.usedPercent, $admission.freeBytes)
    }
    if (-not $process.Start()) { throw "Could not start $Name" }
    $startRecord = [pscustomobject]@{
        phase = $Name; startedUtc = $started.ToString('o'); pid = $process.Id
        processCreationUtc = $process.StartTime.ToUniversalTime().ToString('o'); ramBefore = $ramBefore
        executable = $Executable; argv = @($PhaseArguments); workingDirectory = $psi.WorkingDirectory
        stdout = $stdoutPath; stderr = $stderrPath
    }
    Save-Json ($base + '.start.json') $startRecord
    Write-Host ("PHASE START {0} PID {1} UTC {2}" -f $Name, $process.Id, $startRecord.startedUtc)
    [Console]::Out.Flush()
    $stdoutStream = [IO.File]::Open($stdoutPath,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    $stderrStream = [IO.File]::Open($stderrPath,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    $stdoutTask = $process.StandardOutput.BaseStream.CopyToAsync($stdoutStream)
    $stderrTask = $process.StandardError.BaseStream.CopyToAsync($stderrStream)
    $waitSamples = [System.Collections.Generic.List[object]]::new()
    $peakUsedPercent = $ramBefore.usedPercent
    $ramGuardTriggered = $null
    while (-not $process.WaitForExit(3000)) {
        $ramSample = Get-RamSnapshot
        $processSnapshot = $null
        try { $processSnapshot = Save-PhaseProcessSnapshot $base $process.Id ($process.StartTime.ToUniversalTime()) $Executable $ramSample }
        catch { Write-Host ("Process memory observation failed; RAM guard remains active: {0}" -f $_.Exception.Message) }
        $ownedProcess = Get-Process -Id $process.Id -ErrorAction SilentlyContinue
        $waitSamples.Add([pscustomobject]@{
            capturedUtc = $ramSample.capturedUtc
            ramUsedPercent = $ramSample.usedPercent
            pid = $process.Id
            processCreationUtc = $process.StartTime.ToUniversalTime().ToString('o')
            workingSetBytes = if ($ownedProcess) { [long]$ownedProcess.WorkingSet64 } else { $null }
        })
        if ($ramSample.usedPercent -gt $peakUsedPercent) { $peakUsedPercent = $ramSample.usedPercent }
        if ($ramSample.usedPercent -ge $RamGuardPercent -and -not $process.HasExited) {
            $currentRoot = Get-CimInstance Win32_Process -Filter ("ProcessId={0}" -f $process.Id)
            if ($currentRoot -and -not $process.HasExited) {
                $creationDelta = [Math]::Abs(($currentRoot.CreationDate.ToUniversalTime() - $process.StartTime.ToUniversalTime()).TotalMilliseconds)
                if ($currentRoot.Name -cne [IO.Path]::GetFileName($Executable) -or
                    $currentRoot.ExecutablePath -ine $Executable -or $creationDelta -ge 1) {
                    throw 'RAM guard root identity mismatch; preserve unknown processes'
                }
                $ramGuardTriggered = [pscustomobject]@{
                    capturedUtc = $ramSample.capturedUtc; thresholdPercent = $RamGuardPercent
                    observedPercent = $ramSample.usedPercent; pid = $process.Id
                    executable = $currentRoot.ExecutablePath
                    creationUtc = $currentRoot.CreationDate.ToUniversalTime().ToString('o')
                    action = 'Stop only the verified original phase process and its task descendants'
                }
                Save-Json ($base + '.ram-guard.json') $ramGuardTriggered
                Save-Json ($base + '.ram-guard-processes.json') $processSnapshot
                try { $process.Kill($true) } catch { if (-not $process.HasExited) { throw } }
            }
        }
    }
    $process.WaitForExit()
    $nativeExitCode = $process.ExitCode
    [IO.File]::WriteAllText(($base + '.native-exit.txt'), [string]$nativeExitCode, [Text.UTF8Encoding]::new($false))
    $stdoutTask.GetAwaiter().GetResult()
    $stderrTask.GetAwaiter().GetResult()
    $stdoutStream.Dispose()
    $stderrStream.Dispose()
    $finished = [DateTime]::UtcNow
    $result = [pscustomobject]@{
        phase = $Name; startedUtc = $started.ToString('o'); finishedUtc = $finished.ToString('o')
        elapsedSeconds = [Math]::Round(($finished - $started).TotalSeconds, 3); pid = $process.Id
        processCreationUtc = $process.StartTime.ToUniversalTime().ToString('o'); ramBefore = $ramBefore
        peakRamUsedPercent = $peakUsedPercent; ramWaitSamples = @($waitSamples.ToArray())
        ramGuardTriggered = $ramGuardTriggered; ramPollMilliseconds = 3000
        processMemorySamples = $base + '.memory-process-samples.jsonl'
        executable = $Executable; argv = @($PhaseArguments); exitCode = $process.ExitCode
        stdout = $stdoutPath; stdoutSha256 = (Get-FileHash -LiteralPath $stdoutPath -Algorithm SHA256).Hash
        stderr = $stderrPath; stderrSha256 = (Get-FileHash -LiteralPath $stderrPath -Algorithm SHA256).Hash
    }
    Save-Json ($base + '.result.json') $result
    $script:phases.Add($result)
    } finally {
        if ($stdoutStream) { $stdoutStream.Dispose() }
        if ($stderrStream) { $stderrStream.Dispose() }
        $process.Dispose()
    }
    if ($result.ramGuardTriggered) { throw "$Name stopped by task RAM guard at $($result.ramGuardTriggered.observedPercent)% (threshold $RamGuardPercent%); native exit $($result.exitCode)" }
    if ($result.exitCode -ne 0 -and -not $AllowNonZero) { throw "$Name exited $($result.exitCode)" }
    return $result
}

function Invoke-ExactTests([string[]]$ExpectedNames, [string]$Label) {
    $regex = '^(' + (($ExpectedNames | ForEach-Object { [regex]::Escape($_) }) -join '|') + ')$'
    $inventory = Invoke-Phase "$Label-inventory" $ctest @('--test-dir', $build, '-C', 'Profile', '--show-only=json-v1', '-R', $regex)
    $json = Get-Content -LiteralPath $inventory.stdout -Raw | ConvertFrom-Json
    $actual = @($json.tests | ForEach-Object { [string]$_.name })
    $missing = @($ExpectedNames | Where-Object { $_ -cnotin $actual })
    $extra = @($actual | Where-Object { $_ -cnotin $ExpectedNames })
    if ($actual.Count -ne $ExpectedNames.Count -or $missing.Count -or $extra.Count) {
        throw "$Label CTest inventory mismatch; missing=[$($missing -join ', ')], extra=[$($extra -join ', ')]"
    }
    Save-Json (Join-Path $evidence "$Label-ctest-inventory.json") $json
    $xmlBefore = @{}
    foreach ($testName in $ExpectedNames) {
        $file = ($testName -replace '\.main::TEST_RUN$', '').Replace('::', '_') + '.xml'
        $path = Join-Path $build ('Testing/Gtest/' + $file)
        if ($NativeAPFilter -and $Label -eq 'focal') {
            $path = Join-Path $evidence 'native-image-preset-focal.xml'
            if (Test-Path -LiteralPath $path) { throw 'Native Image Processing XML destination must be absent' }
        }
        $xmlBefore[$testName] = [pscustomobject]@{
            path = $path
            sha256 = if (Test-Path -LiteralPath $path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash } else { $null }
            lastWriteUtc = if (Test-Path -LiteralPath $path) { (Get-Item -LiteralPath $path).LastWriteTimeUtc.ToString('o') } else { $null }
        }
    }
    Save-Json (Join-Path $evidence "$Label-xml-before.json") $xmlBefore
    if ($NativeAPFilter -and $Label -eq 'focal') {
        if ($ExpectedNames.Count -ne 1 -or $ExpectedNames[0] -cne 'Gem::ImageProcessingAtom.Editor.Tests.main::TEST_RUN') { throw 'Direct filter requires exact Image Processing test registration' }
        $registered = $json.tests[0]
        $command = @($registered.command)
        if ($command.Count -lt 4 -or [IO.Path]::GetFileName($command[0]) -cne 'AzTestRunner.exe' -or [IO.Path]::GetFileName($command[1]) -cne 'ImageProcessingAtom.Editor.Tests.dll' -or $command[2] -cne 'AzRunUnitTests') { throw 'Unexpected registered Image Processing native test command' }
        $directArguments = @($command | Select-Object -Skip 1 | Where-Object { -not $_.StartsWith('--gtest_filter=') -and -not $_.StartsWith('--gtest_output=') }) + @(('--gtest_filter=' + $NativeAPFilter), ('--gtest_output=xml:' + $xmlBefore[$ExpectedNames[0]].path))
        $nativeWorkingDirectory = @($registered.properties | Where-Object name -ceq 'WORKING_DIRECTORY')[0].value
        Save-Json (Join-Path $evidence "$Label-native-filter.json") ([pscustomobject]@{registeredCTestName=$registered.name;originalCommand=$command;directCommand=@($command[0])+$directArguments;workingDirectory=$nativeWorkingDirectory;filter=$NativeAPFilter;scope='Focused image-preset authoring tests. Does not claim the full Image Processing suite whose legacy image inputs are LFS pointers.'})
        $testResult = Invoke-Phase "$Label-tests" $command[0] $directArguments -AllowNonZero -WorkingDirectory $nativeWorkingDirectory
    } else {
        $testResult = Invoke-Phase "$Label-tests" $ctest @('--test-dir', $build, '-C', 'Profile', '--output-on-failure', '--no-tests=error', '--timeout', '180', '--parallel', '1', '-R', $regex) -AllowNonZero
    }
    if ($NativeAPFilter -and $Label -eq 'focal' -and $testResult.exitCode -notin @(0,1)) { throw "Native Image Processing process crashed/aborted: $($testResult.exitCode); no test acceptance" }
    $junitDir = Join-Path $evidence 'junit'
    New-Item -ItemType Directory -Path $junitDir -Force | Out-Null
    $results = @()
    foreach ($testName in $ExpectedNames) {
        $path = $xmlBefore[$testName].path
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing fresh XML for $testName" }
        $item = Get-Item -LiteralPath $path
        $nativeStartUTC = [DateTimeOffset]::Parse([string]$testResult.startedUtc, [Globalization.CultureInfo]::InvariantCulture).UtcDateTime
        if ($item.LastWriteTimeUtc -le $nativeStartUTC) { throw "Stale XML for $testName" }
        [xml]$xml = [IO.File]::ReadAllText($path)
        $root = $xml.DocumentElement
        $cases = @($xml.SelectNodes('//testcase'))
        if ([int]$root.GetAttribute('tests') -le 0 -or $cases.Count -ne [int]$root.GetAttribute('tests')) { throw "Invalid case inventory for $testName" }
        Copy-Item -LiteralPath $path -Destination (Join-Path $junitDir $item.Name)
        $results += [pscustomobject]@{
            name = $testName; xml = $path; sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
            lastWriteUtc = $item.LastWriteTimeUtc.ToString('o'); fresh = $true
            tests = [int]$root.GetAttribute('tests'); failures = [int]$root.GetAttribute('failures')
            errors = [int]$root.GetAttribute('errors'); disabled = [int]$root.GetAttribute('disabled'); skipped = [int]$root.GetAttribute('skipped')
            cases = @($cases | ForEach-Object { [pscustomobject]@{
                name = $_.GetAttribute('name'); classname = $_.GetAttribute('classname'); status = $_.GetAttribute('status')
                failures = @($_.SelectNodes('failure') | ForEach-Object { $_.GetAttribute('message') })
            } })
        }
    }
    Save-Json (Join-Path $evidence "$Label-junit-summary.json") ([pscustomobject]@{
        nativeCTestExit = $testResult.exitCode; allowIntentionalFailures = [bool]$AllowTestFailures; suites = $results
        acceptance = 'Parent must review actual case/assertion outcomes; wrapper completion is not product acceptance'
    })
    if ($testResult.exitCode -ne 0 -and -not $AllowTestFailures) { throw "$Label CTest exited $($testResult.exitCode)" }
    if (-not $AllowTestFailures -and @($results | Where-Object { $_.failures -or $_.errors -or $_.disabled -or $_.skipped }).Count) { throw "$Label XML contains failed/disabled/skipped cases" }
}

try {
    $before = Get-InputMap
    $cacheBefore = Get-OfflineCacheState
    $blockedNames = @(
        'Editor.exe', 'AssetProcessor.exe', 'AssetProcessorBatch.exe', 'AssetBuilder.exe',
        'JEEditorFixture.GameLauncher.exe', 'MaterialEditor.exe', 'MaterialCanvas.exe',
        'PassCanvas.exe', 'ShaderManagementConsole.exe', 'cmake.exe', 'MSBuild.exe',
        'cl.exe', 'link.exe', 'ctest.exe', 'AzTestRunner.exe'
    )
    $allProcesses = @(Get-CimInstance Win32_Process)
    $residualNodes = @($allProcesses | Where-Object {
        $_.Name -eq 'MSBuild.exe' -and $_.CommandLine -match '/nodemode:1' -and
        $allProcesses.ProcessId -notcontains $_.ParentProcessId
    })
    $blocking = @($allProcesses | Where-Object {
        ($blockedNames -ccontains $_.Name) -and
        -not ($_.Name -eq 'MSBuild.exe' -and $_.CommandLine -match '/nodemode:1' -and $allProcesses.ProcessId -notcontains $_.ParentProcessId)
    })
    $independentNative = @()
    if ($IndependentNativeRoot) {
        if (-not $SkipFocalBuild -or -not $NativeAPFilter -or $Reconfigure -or $HostTargets.Count -or $HostCTestNames.Count) {
            throw 'Independent build allowance is restricted to tests-only, with no configure/build/hosts'
        }
        $independentRoot = [IO.Path]::GetFullPath($IndependentNativeRoot).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if ($independentRoot.StartsWith($repo, [StringComparison]::OrdinalIgnoreCase) -or $repo.StartsWith($independentRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Independent root overlaps repository' }
        $processById = @{}
        foreach ($item in $allProcesses) { $processById[[int]$item.ProcessId] = $item }
        $independentNative = @($blocking | Where-Object {
            $current = $_
            $visited = [Collections.Generic.HashSet[int]]::new()
            $identifiedIndependent = $false
            while ($current -and $visited.Add([int]$current.ProcessId)) {
                if ([string]$current.CommandLine -like ('*' + $independentRoot + '*')) { $identifiedIndependent = $true; break }
                $current = $processById[[int]$current.ParentProcessId]
            }
            $identifiedIndependent
        })
        $blocking = @($blocking | Where-Object { $independentNative.ProcessId -notcontains $_.ProcessId })
    }
    $env:MSBUILDDISABLENODEREUSE = '1'
    Save-Json (Join-Path $evidence 'preflight.json') ([pscustomobject]@{
        capturedUtc = [DateTime]::UtcNow.ToString('o'); freezePath = $freezePath
        freezeSha256 = $IntegratedFreezeSHA256; inputCount = $before.Count; inputs = $before
        cache = $cacheBefore; activeProcesses = @($blocking | ForEach-Object { [pscustomobject]@{ name = $_.Name; pid = $_.ProcessId; parentPid = $_.ParentProcessId; commandLine = $_.CommandLine } })
        residualMSBuildNodeReuse = @($residualNodes | ForEach-Object { [pscustomobject]@{ pid = $_.ProcessId; parentPid = $_.ParentProcessId; created = $_.CreationDate; commandLine = $_.CommandLine } })
        msbuildDisableNodeReuse = $env:MSBUILDDISABLENODEREUSE
        independentNativeRoot = $IndependentNativeRoot
        preservedIndependentNativeProcesses = @($independentNative | Select-Object ProcessId,ParentProcessId,Name,CreationDate,ExecutablePath,CommandLine)
        focalTargets = $FocalTargets; focalCTestNames = $FocalCTestNames
        hostTargets = $HostTargets; hostCTestNames = $HostCTestNames
    })
    if (-not $cacheBefore.valid) { throw "Offline cache guard failed: $($cacheBefore.missingLines -join '; ')" }
    if ($blocking.Count) { throw "Native/product processes already active: $($blocking.Count)" }

    $cacheBeforeConfigure = Get-OfflineCacheState
    Save-Json (Join-Path $evidence 'cache-before-configure.json') $cacheBeforeConfigure
    if (-not $cacheBeforeConfigure.valid -or $cacheBeforeConfigure.sha256 -cne $cacheBefore.sha256) {
        throw 'Offline cache changed after preflight'
    }
    if ($Reconfigure) {
        $script:configureResult = Invoke-Phase 'configure' $cmake @('-S', $repo, '-B', $build, '-DLY_DISABLE_TEST_MODULES:BOOL=OFF')
    } else {
        $priorConfigurePath = $ReuseConfigureResultPath
        if (-not $priorConfigurePath -or -not $ReuseConfigureCachePath) { throw 'Explicit configure reuse receipts are required' }
        $priorConfigure = Get-Content -LiteralPath $priorConfigurePath -Raw | ConvertFrom-Json
        $priorCachePath = $ReuseConfigureCachePath
        $priorCache = Get-Content -LiteralPath $priorCachePath -Raw | ConvertFrom-Json
        if ($priorConfigure.exitCode -ne 0 -or $priorCache.sha256 -cne $cacheBeforeConfigure.sha256) { throw 'Configure reuse evidence is invalid or cache changed' }
        $script:configureResult = [pscustomobject]@{ reused = $true; evidence = $priorConfigurePath; evidenceSha256 = (Get-FileHash -LiteralPath $priorConfigurePath -Algorithm SHA256).Hash; cacheEvidence = $priorCachePath; cacheSha256 = $priorCache.sha256; reason = 'Parent verified unchanged CMake/filelists since the explicitly assigned configure; relevant inputs are freshly frozen.' }
    }
    $cacheAfterConfigure = Get-OfflineCacheState
    Save-Json (Join-Path $evidence 'cache-after-configure.json') $cacheAfterConfigure
    if (-not $cacheAfterConfigure.valid) { throw "Offline cache guard failed after configure: $($cacheAfterConfigure.missingLines -join '; ')" }
    if ((Get-Content -LiteralPath $cache) -cnotcontains 'LY_DISABLE_TEST_MODULES:BOOL=OFF') { throw 'Tests remain disabled after configure' }

    if ($HostsOnly) {
        if ($Reconfigure -or $SkipFocalBuild -or $NativeAPFilter -or $AllowTestFailures -or $IndependentNativeRoot -or $HostTargets.Count -ne 10 -or $HostCTestNames.Count) { throw 'Hosts-only continuation requires the same ten hosts and no new configure/tests or failure allowance.' }
        if (-not $ReuseFocalReviewPath -or -not $ReuseFocalReviewSHA256 -or -not $ReuseFocalPostflightPath) { throw 'Explicit successful current 175-case parent evidence is required.' }
        if ((Get-FileHash -LiteralPath $ReuseFocalReviewPath).Hash -cne $ReuseFocalReviewSHA256) { throw 'Prior parent review identity drift.' }
        $priorReview = Get-Content -LiteralPath $ReuseFocalReviewPath -Raw | ConvertFrom-Json
        $priorPostflight = Get-Content -LiteralPath $ReuseFocalPostflightPath -Raw | ConvertFrom-Json
        if ($priorReview.focalBuildExit -ne 0 -or $priorReview.nativeCTestExit -ne 0 -or $priorReview.actualCaseCount -ne 175 -or $priorReview.uniqueCaseCount -ne 175 -or $priorReview.suites.Count -ne 5) { throw 'Prior current 175-case native result was not successful.' }
        if ($priorPostflight.freezeSha256 -cne $IntegratedFreezeSHA256 -or $priorPostflight.inputCount -ne $InputCount -or $priorPostflight.mismatches.Count -ne 0) { throw 'Prior test/source freeze does not match current inputs.' }
        foreach ($suite in $priorReview.suites) {
            if ($suite.failures -ne 0 -or $suite.errors -ne 0 -or $suite.disabled -ne 0 -or $suite.skips -ne 0 -or (Get-FileHash -LiteralPath $suite.copy).Hash -cne $suite.sha256) { throw 'Prior actual XML evidence is not reusable.' }
        }
        $priorTestPath = Join-Path ([IO.Path]::GetDirectoryName($ReuseFocalPostflightPath)) 'focal-tests.result.json'
        $priorTests = Get-Content -LiteralPath $priorTestPath -Raw | ConvertFrom-Json
        if ($priorTests.phase -cne 'focal-tests' -or $priorTests.exitCode -ne 0 -or (Get-FileHash -LiteralPath $priorTests.stdout).Hash -cne $priorTests.stdoutSha256 -or (Get-FileHash -LiteralPath $priorTests.stderr).Hash -cne $priorTests.stderrSha256) { throw 'Prior native CTest receipts or logs changed.' }
        $expectedHosts = @('Editor','AssetProcessor','AssetProcessorBatch','AssetBuilder','SerializeContextTools','MaterialEditor','MaterialCanvas','PassCanvas','ShaderManagementConsole','JEEditorFixture.GameLauncher')
        foreach ($hostTarget in $expectedHosts) { if ($HostTargets -cnotcontains $hostTarget) { throw "Missing current host: $hostTarget" } }
        Save-Json (Join-Path $evidence 'reused-current-175-tests.json') ([pscustomobject]@{ parentReview=$ReuseFocalReviewPath; parentReviewSHA256=$ReuseFocalReviewSHA256; priorPostflight=$ReuseFocalPostflightPath; priorPostflightSHA256=(Get-FileHash -LiteralPath $ReuseFocalPostflightPath).Hash; nativeTestResult=$priorTestPath; nativeTestResultSHA256=(Get-FileHash -LiteralPath $priorTestPath).Hash; sameFreezeSHA256=$IntegratedFreezeSHA256; currentPreflightInputs=$before.Count; actualCases=175; uniqueCases=175; nativeCTestExit=0; currentCppOrCMakeChanges=0; newNativeTestsRun=$false; reason='The affected suites passed on these unchanged frozen inputs; continue only the interrupted host phase.' })
    } elseif ($SkipFocalBuild) {
        if (-not $ReuseBuildResultPath -or $FocalTargets.Count -ne 1 -or $FocalTargets[0] -cne 'EditorLib.Tests') { throw 'Explicit prior native Editor build required' }
        $priorBuild = Get-Content -Raw -LiteralPath $ReuseBuildResultPath | ConvertFrom-Json
        $priorPost = Get-Content -Raw -LiteralPath (Join-Path ([IO.Path]::GetDirectoryName($ReuseBuildResultPath)) 'postflight.json') | ConvertFrom-Json
        if ($priorBuild.exitCode -ne 0 -or $priorPost.freezeSha256 -cne $IntegratedFreezeSHA256 -or $priorPost.mismatches.Count -ne 0) { throw 'Build/source reuse mismatch' }
        $dll = Join-Path $build 'bin/profile/EditorLib.Tests.dll'
        Save-Json (Join-Path $evidence 'reused-build-focal.json') ([pscustomobject]@{priorResult=$ReuseBuildResultPath;priorResultSHA256=(Get-FileHash -LiteralPath $ReuseBuildResultPath).Hash;freezeSHA256=$IntegratedFreezeSHA256;dll=$dll;dllSHA256=(Get-FileHash -LiteralPath $dll).Hash;reason='Same frozen sources and completed successful native build; focused diagnostic changes only the test filter.'})
    } else {
        Invoke-Phase 'build-focal' $cmake (@('--build', $build, '--config', 'Profile', '--target') + $FocalTargets + @('--parallel', '1', '--', '/p:UseMultiToolTask=true', '/p:MultiProcCL=true', '/p:MultiProcMaxCount=1', '/p:EnableClServerMode=false', '/p:EnforceProcessCountAcrossBuilds=true', '/p:CL_MPCount=1', '/nodeReuse:false')) | Out-Null
    }
    if (-not $HostsOnly) { Invoke-ExactTests $FocalCTestNames 'focal' }
    if ($HostTargets.Count) {
    Invoke-Phase 'build-hosts' $cmake (@('--build', $build, '--config', 'Profile', '--target') + $HostTargets + @('--parallel', '1', '--', '/p:UseMultiToolTask=true', '/p:MultiProcCL=true', '/p:MultiProcMaxCount=1', '/p:EnableClServerMode=false', '/p:EnforceProcessCountAcrossBuilds=true', '/p:CL_MPCount=1', '/nodeReuse:false')) | Out-Null
    }
    if ($HostCTestNames.Count) { Invoke-ExactTests $HostCTestNames 'host' }
} catch {
    $script:fatal = $_.Exception.Message
    Save-Json (Join-Path $evidence 'failure.json') ([pscustomobject]@{ capturedUtc = [DateTime]::UtcNow.ToString('o'); message = $script:fatal; stack = $_.ScriptStackTrace; phases = @($script:phases.ToArray()) })
    Write-Host ('STOP: ' + $script:fatal)
} finally {
    $post = [ordered]@{ capturedUtc = [DateTime]::UtcNow.ToString('o'); freezePath = $freezePath; freezeSha256 = $IntegratedFreezeSHA256; inputCount = $freeze.inputs.Count; inputs = [ordered]@{}; mismatches = [System.Collections.Generic.List[object]]::new(); phases = @($script:phases.ToArray()); configure = $script:configureResult; fatal = $script:fatal }
    foreach ($entry in $freeze.inputs) {
        $path = [string]$entry.path
        if (-not [IO.Path]::IsPathRooted($path)) { $path = Join-Path $repo $path }
        $path = [IO.Path]::GetFullPath($path)
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $post.mismatches.Add([pscustomobject]@{ path = $path; status = 'MISSING' }); continue }
        $item = Get-Item -LiteralPath $path
        $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
        $post.inputs[$path] = [pscustomobject]@{ bytes = $item.Length; sha256 = $hash }
        if ($item.Length -ne [long]$entry.bytes -or $hash -cne [string]$entry.sha256) { $post.mismatches.Add([pscustomobject]@{ path = $path; status = 'MISMATCH'; bytes = $item.Length; sha256 = $hash }) }
    }
    Save-Json (Join-Path $evidence 'postflight.json') $post
    $summaryExit = if ($script:fatal -or $post.mismatches.Count) { 1 } else { 0 }
    Save-Json (Join-Path $evidence 'summary.json') ([pscustomobject]@{ endedUtc = [DateTime]::UtcNow.ToString('o'); exitCode = $summaryExit; inputCount = $post.inputCount; postflightMismatches = $post.mismatches.Count; phases = @($script:phases.ToArray()); configure = $script:configureResult; fatal = $script:fatal })
}
if ($script:fatal) { exit 1 }
if ($post.mismatches.Count) { exit 1 }
exit 0
